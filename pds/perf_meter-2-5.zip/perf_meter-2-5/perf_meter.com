$!========================================================================
$!
$! Name      : PERF_METER
$!
$! Purpose   : Define user logicals and run PERF_METER as a detached process
$!
$! Arguments : P1 = [SPAWN]/NOSPAWN, spawn subprocess or run directly.
$!
$! Created  31-JUL-1990					Alan M. Jonckheere
$!
$! Modified 23-May-1995 to run with version 2.2		RDS
$!
$! Modified 31-May-1995 to spot DEcnet devices		Phil Ottewell
$!
$!========================================================================
$   ON ERROR     THEN $ GOTO EXIT
$   ON CONTROL_Y THEN $ GOTO EXIT
$! Allow non-VUE process to use same command file without error message
$ IF F$TYPE(vue$suppress_output_popup).EQS."" THEN vue$suppress_output_popup="!"
$ vue$suppress_output_popup
$!
$!========================================================================
$!   PFM$DATA contains the UID data file PERF_METER.UID for display
$!   DECW$USER_DEFAULTS contains PERFMETER.DAT with user definable
$!      parameters 
$!========================================================================
$!!   define pfm$exe     sys$system:	!<---modify to point to .EXE file
$!!  define pfm$data    sys$manager:	!<---modify to point to .UID file
$! this next line only works if we are the only one playing with 
$!    decw$user_defaults logical name definition
$!   define decw$user_defaults   -     !first check user area, if not use default
$!!sys$login,pfm$data        		!<---modify to point to .DAT file
$!
$!========================================================================
$!   To personalize the display, that is to change the disks you wish to
$!   monitor, copy this file to your area. Change any of the
$!   PFM$DEVICE_*_NAME logicals to the name of the disk you want to
$!   monitor. Change the corresponding PFM$DEVICE_*_TITLE to the title you 
$!   want to put on the display. Then start the program by running the
$!   modified command file. 
$!   
$!   You can change the default position and sampling time by copying
$!   PerFMeter.DAT to your login directory and modifying it.
$!   You can also control the colors used for display from that file.
$!========================================================================
$!
$ net_dev_list = ""
$dev_loop:
$ net_device = F$DEVICE("*","SCOM",,0)
$   IF net_device.NES.""
$   THEN
$     owner_proc = F$GETJPI(F$GETDVI(net_device,"PID"),"PRCNAM")
$     IF owner_proc.EQS."NETACP" .OR. owner_proc.EQS."DNS$ADVER"
$     THEN
$       IF net_dev_list.NES.""
$       THEN
$         net_dev_list = net_dev_list + "," + net_device
$       ELSE
$         net_dev_list = net_device
$       ENDIF
$     ENDIF
$   ENDIF
$ IF net_device.NES."" THEN $ GOTO dev_loop
$ WRITE SYS$OUTPUT "DECnet devices ",net_dev_list
$!
$! PFM$DEVICE_0_NAME is SYS$SYSDEVICE by default!
$!
$! DEFINE PFM$DEVICE_0_NAME    SYS$SYSDEVICE	!<---modify
$! DEFINE PFM$DEVICE_0_TITLE   SYS$SYSDEVICE:	!<---modify
$  DEFINE PFM$DEVICE_1_NAME    'net_dev_list'	!<---modify
$  DEFINE PFM$DEVICE_1_TITLE   "DECnet" 	!<---modify
$!!  DEFINE PFM$DEVICE_2_NAME    PDS$DISK	!<---modify
$!!  DEFINE PFM$DEVICE_2_TITLE   PDS$DISK:	!<---modify
$!!  DEFINE PFM$DEVICE_3_NAME    DEV$DISK	!<---modify
$!!  DEFINE PFM$DEVICE_3_TITLE   DEV$DISK:	!<---modify
$!
$ IF (p1.EQS."NOSPAWN")
$ THEN
$   RUN PFM$EXE:PERF_METER
$ ELSE
$   SPAWN/NOWAIT/INP=NL:/OUT=NL: RUN PFM$EXE:PERF_METER
$ ENDIF
$!
$EXIT:
$ EXIT
