# VMS make file for MMS or MMK
#
# Makefile template for GIF combining lib
# This file is used by the configure program to generate Makefile
# muquit@semcor.com
# 07-11-95, -- muquit
# 09-17-95 (Count 1.5), -- muquit
# 11-25-95 (Count 2.0), -- muquit
#
# port to VMS by phil@pottsoft.demon.co.uk
# 07-OCT-1996

CC= CC/PREFIX=ALL
DEFS=  /DEFINE=("STRICT_MODE=1","STDC_HEADERS=1","HAVE_STRING_H=1","HAVE_FCNTL_H=0",\
  "HAVE_MALLOC_H=0","HAVE_SYS_FILE_H=1","HAVE_UNISTD_H=1","HAVE_FLOCK=0")
INCLUDES= /INCLUDE=([])
DEFINES= $(INCLUDES) $(DEFS) 

# add /NOOPT/DEBUG to CFLAGS for debug version
CFLAGS=  $(DEFINES)

OBJS = crbasei.obj,allocim.obj,readgif.obj,rddata.obj,dstraimg.obj,\
       readblk.obj,lzwdec.obj,syncimg.obj,duplicim.obj,writegif.obj,\
       lsbfwrs.obj,lzwenc.obj,uncmpimg.obj,readim.obj,flatten.obj,\
       signature.obj,quantize.obj,compimg.obj,rgbtran.obj,tranrgb.obj,\
       compcmap.obj,frameim.obj,modulate.obj,alphaim.obj,setpixel.obj,\
       getfinfo.obj,imgstr.obj,gdfonts.obj,negate.obj,rotate.obj,getsize.obj,\
       opaqim.obj,cropim.obj

all : combine.olb

combine.olb : $(OBJS)
        IF F$SEARCH("combine.olb").EQS."" THEN $ LIBRARY/CREATE combine.olb
	LIBRARY/INSERT/REPLACE combine.olb $(OBJS) 

combine.obj : combine.h

clean :
	DELETE *.OBJ;
