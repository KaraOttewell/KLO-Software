#ifndef _COUNT_CONFIG_H
#define _COUNT_CONFIG_H 1

/*
** This file for VMS
** Count-config written by muquit@semcor.com
** Counter Version: 2.3
** created on: Sat Feb 17 18:48:19 EST 1996
**
**  If you edit this file, you better make sure you know what are 
**  you doing.
**
**  Oh dear. Modified by Phil Ottewell, phil@pottsoft.demon.co.uk
**  07-OCT-1996
*/
#define ConfigDir "WWW_ROOT:[WCOUNT.CONF]"
#define ConfigFile "count.cfg"
#define DataDir "WWW_ROOT:[WCOUNT.DATA]"
#define DigitDir "WWW_ROOT:[WCOUNT.DIGITS."
#define LogDir "WWW_ROOT:[WCOUNT.LOG]"
#define LogFile "Count23.log"

/*****************************************************************************
* Defaults parameters not supplied in calling.
* Change 'em here if you insist...
*****************************************************************************/
#define DefaultMaxDigits       6      /* Max digits in output        */
#define DefaultLeftpad         True   /* 0 indicates no padding      */

#define DefaultThickness       6       /* 0 indicates no frame        */
#define Default_FrameRed       100
#define DefaultFrameGreen      139      /* RGB=0;0;0 for black         */
#define DefaultFrameBlue       216
#define FRGB_ImpliedFt         5       /* Use this FT if we get FRGB only */

#define DefaultTransparency       False    /* 0 indicates no transparent  */
#define DefaultTransparentRed     0
#define DefaultTransparentGreen   0 /* RGB=255;255;255 for white   */
#define DefaultTransparentBlue    0
#define TRGBImpliedTr              1   /* Use this TR if we get TRRBG only */

#define DefaultStartCount          1      /* Initial counter value       */
#define DefaultShowCount           1      /* 1 indicates count is shown  */
#define DfForRandom            "RANDOM"    /* This DF name means use rand */
#define DefaultDatafile        "RANDOM"    /* Make rand the default, too  */

#define DefaultDigitsStyle       "A" /* Use GIFs in digits/A/files  */
#define ParamDelimiters           "|&"    /* These separate params       */

/*****************************************************************************
* This specifies a file listing RGB values mapped to names.
* If not defined, no attempt to use RGB names is made.  If you're not sure,   
* just leave this be--it's okay if the file does not exist.
*
* When RGB_MAPPING_ISERROR is set to 1, an error is returned when RGB name
* value is used, but it shows the corresponding RGB triplet.  This is done
* so RGB names can be looked up, but yet not allow users to make constant
* use of this very ineffiecient lookup.
*****************************************************************************/
#define RgbMappingDict        "WWW_ROOT:[WCOUNT]rgb.txt"
/*****************************************************************************
* End of parameter defaults
*****************************************************************************/
#endif /* _COUNT_CONFIG_H*/
