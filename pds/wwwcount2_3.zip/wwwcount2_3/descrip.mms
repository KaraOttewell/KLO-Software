# Makefile template for Count 2.0
# This file is used by the configure program to generate Makefile
# by Muhammad A Muquit
# 04/10/95, muquit@semcor.com
# http://www.semcor.com/~muquit/
#####
# port to VMS 6.2 VAX and Alpha by phil@pottsoft.demon.co.uk
# 07-OCT-1996
##

COMBINE = [.COMBINE]
##
# do not undefine ACESS_AUTH
##
DEFS = /DEFINE=("STDC_HEADERS=1","HAVE_STRING_H=1","HAVE_UNISTD_H=1",\
  "HAVE_FCNTL_H=0","HAVE_MALLOC_H=0","HAVE_MKTIME","ACCESS_AUTH=1")
INCLUDES = /INCLUDE=([],$(COMBINE))
LIBS = $(COMBINE)COMBINE.OLB
DEFINES= $(INCLUDES) $(DEFS)
CFLAGS= /PREFIX=ALL $(DEFINES)

SRCS= main.c,parse.c,strimage.c
OBJS= main.obj;,parse.obj;,strimage.obj;

#
# make the GIF combining library
#
COUNT_PROG.EXE : $(OBJS),$(LIBS)
        LINK $(OBJS) /EXECUTABLE=COUNT_PROG.EXE,$(LIBS)/LIBRARY

$(LIBS) :
        old_default = F$ENVIRONMENT("DEFAULT")
        SET DEFAULT $(COMBINE)
        MMK
        SET DEFAULT 'old_default'

MAIN.OBJ  : COUNT.H,CONFIGVMS.h
PARSE.OBJ : COUNT.H,CONFIGVMS.h

CLEAN :
	DELETE *.OBJ;
