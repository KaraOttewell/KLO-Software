/* 
Copyright 1997 COMPUTER GENERATION, INC.,

The software is provided "as is", without warranty of any kind, express
or implied, including but not limited to the warranties of
merchantability, fitness for a particular purpose and noninfringement.
In no event shall Computer Generation, inc. nor the author be liable for
any claim, damages or other liability, whether in an action of contract,
tort or otherwise, arising from, out of or in connection with the
software or the use or other dealings in the software.

Permission to use, copy, modify, and distribute this software and its
documentation for any purpose and without fee is hereby granted,
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in
supporting documentation.

Author:
Gary Aviv 
Computer Generation, Inc.,
gary@compgen.com
*/
/*
;+
LiteClueMotif	--	Motif Test program for LiteClue widget

Author:		Gary Aviv (gary@compgen.com)

Functions:	Provide a Motif test fixture for LiteClue widget
 
;-
*/

/*	Revision Information:

$Log$

$log
Initial version.
$log

*/

#ifndef __VMS
# define 	VERSION "$Revision$"
# ident		"@(#)$Id$ $Revision$"
#else
# define        VERSION "1.3"
# pragma module LiteClueMotif "LiteClueMotif 1.3"
#endif

#define	PGMNAME		"LiteClueMotif"

/*----------- Include Files -------------*/

#include <stdio.h>
#include <stdlib.h>

#include <Xm/MainW.h>
#include <Xm/PushB.h>
#include <Xm/RowColumn.h>

#ifndef __VMS 
# include <LiteClue.h>
#else
# include "LiteClue.h"
#endif

static void exit_cb(Widget  widg, XtPointer ctx ,XtPointer   cb_data);

int main(int argc, char *argv[] )
{
	Widget toplevel;
	XtAppContext AppContext;
	Widget liteClue, main_window, work_area, popup, menub, megatb, pulldown;


  	toplevel = XtVaAppInitialize(&AppContext,
			"LiteClueMotif",
			NULL, 0, /*appl cmd line options*/
			&argc, argv, 
			NULL, /* fallback resources */
			NULL);	/* top level resources, VA args */

	liteClue = XtVaCreatePopupShell( "popup_shell", 
		xcgLiteClueWidgetClass, toplevel, NULL);

/*	Create Application Main Window */
	main_window = XmCreateMainWindow(toplevel,"main_window",NULL,0);
	XtManageChild(main_window);

/*	Create the work area to contain the buttons */
	work_area = XmCreateRowColumn(main_window,"work_area",NULL,0);
	XtVaSetValues(work_area,XmNorientation,XmHORIZONTAL,NULL);
	XtManageChild(work_area);

/*	Notify Geometry Manager of all the bits of the main window */
	XmMainWindowSetAreas(main_window, NULL, NULL, NULL, NULL, work_area);

	megatb = XmCreatePushButton(work_area, "Button1", NULL, 0);
	XcgLiteClueAddWidget(liteClue, megatb, "Don't press this button", 0, 0);
	XtManageChild(megatb);

	megatb = XmCreatePushButton(work_area, "Button2", NULL, 0);
	XcgLiteClueAddWidget(liteClue, megatb, "Don't press this either", 0, 0);
	XtManageChild(megatb);

	megatb = XmCreatePushButton(work_area, "Exit", NULL, 0);
	XcgLiteClueAddWidget(liteClue, megatb,  "Exit Now", 0, 0);
	XtAddCallback(megatb,XmNactivateCallback,(XtCallbackProc)exit_cb,NULL);
	XtManageChild(megatb);

/*	Set Values for wait periods */
	XtVaSetValues(liteClue, XgcNwaitPeriod, 1000, NULL);
	XtVaSetValues(liteClue, XgcNcancelWaitPeriod, 500, NULL);

	XtRealizeWidget(toplevel);

	XtAppMainLoop(AppContext);
}

static void exit_cb(Widget  widg, XtPointer ctx ,XtPointer   cb_data)
{
	exit(0);
}
