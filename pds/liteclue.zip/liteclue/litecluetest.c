/* 
Copyright 1996 COMPUTER GENERATION, INC.,

The software is provided "as is", without warranty of any kind, express
or implied, including but not limited to the warranties of
merchantability, fitness for a particular purpose and noninfringement.
In no event shall Computer Generation, inc. nor the author be liable for
any claim, damages or other liability, whether in an action of contract,
tort or otherwise, arising from, out of or in connection with the
software or the use or other dealings in the software.

Permission to use, copy, modify, and distribute this software and its
documentation for any purpose and without fee is hereby granted,
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in
supporting documentation.

Author:
Gary Aviv 
Computer Generation, Inc.,
gary@compgen.com
*/
/*
;+
LiteClueTest	--	Test program for LiteClue widget

Author:		Gary Aviv (gary@compgen.com)

Functions:	Provide a test fixture for LiteClue widget
 
;-
*/

/*	Revision Information:

$Log$

$log
Initial version.
$log

*/

#ifndef __VMS
#define 	VERSION "$Revision$"
#ident		"@(#)$Id$ $Revision$"
#else
# define        VERSION "1.2"
# pragma module LiteClueTest "LiteClueTest 1.2"
#endif

#define	PGMNAME		"LiteClueTest"

/*----------- Include Files -------------*/

#include <stdio.h>
#include <stdlib.h>

#ifdef NeedFunctionPrototypes
#undef NeedFunctionPrototypes
#endif
#define NeedFunctionPrototypes 1

#ifdef NeedVarargsPrototypes
#undef NeedVarargsPrototypes
#endif
#define NeedVarargsPrototypes 1

#include <X11/Intrinsic.h>
#ifndef __VMS 
#include <X11/Xaw/SimpleMenu.h>
#include <X11/Xaw/Box.h>
#include <X11/Xaw/Command.h>
#include <LiteClue.h>
#else
# include <Xaw_Directory/SimpleMenu.h>
# include <Xaw_Directory/Box.h>
# include <Xaw_Directory/Command.h>
# include "LiteClue.h"
#endif

static void exit_cb(Widget  widg, XtPointer ctx ,XtPointer   cb_data);
static Widget toplevel;
static int debug = 0;
static 	XtAppContext AppContext;

main(int 	argc, char 	*argv[])
{
	Widget liteClue, menubar, popup, menub, megatb, pulldown;


  	toplevel = XtVaAppInitialize(&AppContext,
			"LiteClueTest",
			NULL, 0, /*appl cmd line options*/
			&argc, argv, 
			NULL, /* fallback resources */
			NULL);	/* top level resources, VA args */

	liteClue = XtVaCreatePopupShell( 
		"popup_shell", 
		xcgLiteClueWidgetClass, toplevel,
		NULL);

	menub = XtVaCreateManagedWidget("menub", boxWidgetClass, 
			toplevel, XtNorientation, XtEhorizontal, NULL);

	megatb = XtVaCreateManagedWidget("Button1", commandWidgetClass, 
		menub, XtNlabel, "Button1", NULL);
	XcgLiteClueAddWidget(liteClue, megatb,  "LiteClue1", 0, 0);

	megatb = XtVaCreateManagedWidget("Button2", commandWidgetClass, 
		menub, XtNlabel, "Button2", NULL);
	XcgLiteClueAddWidget(liteClue, megatb,  "LiteClue2", 0, 0);

	megatb = XtVaCreateManagedWidget("Exit", commandWidgetClass, 
		menub, XtNlabel, "Exit", NULL);
	XcgLiteClueAddWidget(liteClue, megatb,  "Exit Now", 0, 0);
	XtAddCallback(megatb,   XtNcallback, 
		(XtCallbackProc) exit_cb, NULL );

#if 0
	{	/* Set Values test */
	int wait, cancel;
	XtVaSetValues(liteClue, XgcNwaitPeriod, 1000, NULL);
	XtVaGetValues(liteClue, XgcNwaitPeriod, &wait, NULL);
	fprintf(stderr,"waitPeriod=%d\n", wait);
	}
#endif
	XtRealizeWidget(toplevel);

	XtAppMainLoop(AppContext);
}

static void exit_cb(Widget  widg, XtPointer ctx ,XtPointer   cb_data)
{
	exit(0);
}

