                        LinkSysLog for OpenVMS
                        ----------------------

             LinkSysLog is copyright (C) Phil Ottewell 2002.
    This copyright applies to all source code, compiled code, documentation,
                    graphics and auxiliary files. 

This utility is a Motif/X-Windows application for OpenVMS VAX and Alpha
machines which enables them to display and save the logging information
broadcast by LinkSys gateway firewall/routers such as the BEFSR41. It displays
the inbound and outbound connections being made, or refused, through the
firewall, and allows you to do text searches and copy to the clipboard. The
window is split into two panes, one for inbound and one for outbound
connections. The displayed lists can optionally be filtered by port number
and/or IP address, though all information is still captured in the log file.
The LINKSYSLOG.HLP file describes the various options available, such as
beeping on incoming connections, and changing the log file name. 

This Motif version of LinkSysLog should compile and run on VMS, VAX or Alpha 
on versions 6.2 onwards. It requires that you have a TCPIP product installed 
such as Compaq TCPIP 5.1, UCX 4.2, or Process Software's Multinet.

Building
--------
To compile, if you have Compaq MMS or MadGoat MMK installed just go to the 
LINKSYSLOG directory and type MMK or MMS. You need a C compiler of course, such
as DEC C or Compaq C for OpenVMS. 

You will need the XPM library, which you can download from
ftp://ftp.x.org/contrib/libraries/ to build LinkSysLog yourself. I used
xpm-3.4k.tar.gz . To build the XPM library, copy the file DESCRIP.MMS_XPM from
here into the [.LIB] subdirectory of the Xpm distribution, renamed to
DESCRIP.MMS of course. Then use MMK or MMS in the Xpm [.LIB] directory.

In the LINKSYSLOG distribution directory, edit the DESCRIP.MMS so that it knows 
where to find your XPM library and header. Look for the line

XPM_LOCATION = PDS$DISK:[PDS.XPM-3_4K.LIB] 

and change this to be location of your Xpm header, Xpm.h. You can now build 
LINKSYSLOG by typing MMK (or MMS) in the LINKSYSLOG directory.

Once you have the XPM library built, you can rebuild LINKSYSLOG by using the MAKE.
COM command file: @MAKE builds the normal version, and @MAKE D builds the debug 
version. You will need to edit the line

$ xpm_location := PDS$DISK:[PDS.XPM-3_4K.LIB]

to pint at your XPM header and OLB directory.

Running
-------
To set up the command, @SETUP in the LINKSYSLOG directory and the symbol
LINKSYSLOG will be set up to point to the correct location. The Alpha executable
is called LINKSYSLOG.EXE_ALPHA and the VAX one is called LINKSYSLOG.EXE . 

The executables supplied are linked for VAX VMS 6.2 and Alpha VMS 7.3, so if you
get errors concerning version mismatches, just delete or rename the supplied
.EXE and .EXE_ALPHA, and relink on your system - MMK or MMS will do this for
you, or look at the MAKE.COM and LINK by hand. 

Before running the program, you should copy the LINKSYSLOG.DAT Motif resource 
file included with this distribution into your DECW$USER_DEFAULTS directory and 
edit it appropriately, for example the router IP address is set in the line 
below

! Set router IP address you want to receive SNMP trap messages from
*LinkSysRouterIPAddresses: 192.168.0.1

The LinkSYS routers come preconfigured with an IP address of 192.168.1.1 .
You can also set things like the print command using the resource file.

Common Desktop Environment (CDE) Icons
--------------------------------------
My CDE setup files are included in the LINKSYSLOG_CDE_FILES.ZIP file. If you 
copy it to your SYS$LOGIN: directory and unzip it, it will create the files
in the [.DT.ICONS] and [.DT.TYPES] subdirectories which will let you add it to 
the CDE "Personal Applications" menu by opening the "File Manager" (the little 
file draw which is, in the default configuration, the third icon from the left 
at the bottom of the screen, clicking on the arrow above the DECTerm icon
(4th from the left) then dragging linksyslog.; from the "File Manager" to the 
"Install Icon" place on the "Personal Applications" menu. You will need to edit 
[.DT.TYPES]LINKSYSLOG.DT to change the line

    EXEC_STRING   mc pds$disk:[pds.linksyslog]linksyslog.exe_alpha

to be the correct command to launch the executable on your system. Of course, 
you can also use this application from the old-style VMS Motif Window Manager
by adding a new menu item, or you can just set up the symbol and run it from the 
command line.

Feedback
--------
Please report any problems to me <phil@XZYpottsoft_REMOVEXYZ.com>

Phil Ottewell 21-JUL-2002

Feel free to sen feature request, though I can't promise to do them because I 
just wrote this in my own time for a bit of fun. I would love to hear from 
anyone who is using this program, and will try to help if you encounter 
difficulties.

Disclaimer and Legal Stuff
--------------------------
This program is free and may be used for commercial or non-commercial
applications provided you are not breaking applicable national or international
laws, and you have legitimate access to the systems on which you are using it.
It is NOT covered by the GNU public license, and I give permission to use
parts of it in your own programs without in any way compromising your ownership 
of those programs. If you do intend to use the program or parts of the source 
for commercial purpose, I'd appreciate a courtesy e-mail. Please don't sell this
program, though you are free to sell your services, if you wish, if you install
it for other people or organizations.

This utility is provided "as is," and comes with absolutely no warranty,
express or implied, to the extent permitted by applicable law,
including but not limited to the implied warranties of merchantability
or fitness for a particular purpose.

In no event shall the author or contributors be liable for any direct, indirect,
incidental, special, exemplary, or consequential damages (including, but not
limited to, procurement of substitute goods or services; loss of use, data, or
profits; or business interruption) however caused and on any theory of
liability, whether in contract, strict liability, or tort (including negligence
or otherwise) arising in any way out of the use of this work, even if advised of
the possibility of such damage. 
