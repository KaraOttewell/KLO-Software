
#ifndef TRUE
#define TRUE	1
#define FALSE	0
#endif

typedef	unsigned char	byte;
typedef	short		int16;
typedef long		int32;
typedef unsigned short	word;
typedef unsigned long	lword;

#ifdef DOS
#define random()	rand()
#define srandom(s)	srand(s)
#endif

#ifdef SYSV
#define random()	lrand48()
#define srandom(s)	srand48(s)
#endif

#ifdef __VMS
# include <unistd.h>
# if ( __VMS_VER < 70000000)
#  include <math.h>
#  define random rand
#  define srandom srand
# endif
#endif /* #ifdef __VMS */
