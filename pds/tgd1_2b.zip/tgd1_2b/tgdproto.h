#ifndef TGDPROTO_H
#define TGDPROTO_H 1

/* Function prototypes */
void tgdcommand( int argc, char *argv[] );
void die( const char *s );
void tgdputs( const char *s );
void tgdputerr( const char *s );
static void init(void);
static void tgdgo( FILE *fp );
COLOUR *colourbyname( TIM *tim, const char *s );
COLOUR *colourbyid( TIM *tim, int colourid );
TIM *timopen( const char *s );
void timset( TIM *tim );
TIM *timbyname( const char *s );
TGDFONT *fontbyname( const char *s );
void tgddebug( int argc, char *argv[] );
void tgdstringcenter( int argc, char *argv[] );
void tgdstockimage( int argc, char *argv[] );
void tgdargdestroy( int argc, char *argv[] );
void tgdshowvector( int argc, char *argv[] );
int tgdtokenize( char *line, char *argv[] );
void loadfonts(void);
void unloadfonts(void);

void imagearc( int argc, char *argv[] );
void imageblue( int argc, char *argv[] );
void imageboundssafe( int argc, char *argv[] );
void imagechar( int argc, char *argv[] );
void imagecharup( int argc, char *argv[] );
void imagecolorallocate( int argc, char *argv[] );
void imagecolorclosest( int argc, char *argv[] );
void imagecolordeallocate( int argc, char *argv[] );
void imagecolorexact( int argc, char *argv[] );
void imagecolortransparent( int argc, char *argv[] );
void imagecopy( int argc, char *argv[] );
void imagecopyresized( int argc, char *argv[] );
void imagecreate( int argc, char *argv[] );
void imagecreatefromgd( int argc, char *argv[] );
void imagecreatefromgif( int argc, char *argv[] );
void imagecreatefromxbm( int argc, char *argv[] );
void imagecolorstotal( int argc, char *argv[] );
void imagedashedline( int argc, char *argv[] );
void imagedestroy( int argc, char *argv[] );
void imagefill( int argc, char *argv[] );
void imagefilltoborder( int argc, char *argv[] );
void imagefilledrectangle( int argc, char *argv[] );
void imagegd( int argc, char *argv[] );
void imagegetinterlaced( int argc, char *argv[] );
void imagegetpixel( int argc, char *argv[] );
void imagegettransparent( int argc, char *argv[] );
void imagegif( int argc, char *argv[] );
void imagegreen( int argc, char *argv[] );
void imageinterlace( int argc, char *argv[] );
void imageline( int argc, char *argv[] );
void imagefilledpolygon( int argc, char *argv[] );
void imagepolygon( int argc, char *argv[] );
void imagerectangle( int argc, char *argv[] );
void imagered( int argc, char *argv[] );
void imagesx( int argc, char *argv[] );
void imagesy( int argc, char *argv[] );
void imagesetbrush( int argc, char *argv[] );
void imagesetpixel( int argc, char *argv[] );
void imagesetstyle( int argc, char *argv[] );
void imagesettile( int argc, char *argv[] );
void imagestring( int argc, char *argv[] );
void imagestringup( int argc, char *argv[] );

#endif /* TGDPROTO_H */ /* End of file tgdproto.h */
