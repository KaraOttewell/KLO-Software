#	This is the Makefile for tgd
#
#	tgd is a text interface to the gd library
#
#	Bradley K. Sherman, June 1995
#	Copyright (c) United States of America
#
#	The basic idea here is that you need the
#	gd1.2 library to compile.  This makefile
#	assumes that it is in a subdirectory called
#	[.GD1_2]
#
PROG	 = tgd.exe
GDHOME   = [.GD1_2]
GDLIB    = [.GD1_2]LIBGD.OLB
CFLAGS	  = /PREFIX=ALL/INCLUDE=([],$(GDHOME))

FONT1O   = tgdFont10x20.obj,tgdFont12x24.obj,tgdFont5x8.obj,tgdFont6x10.obj
FONT2O   = tgdFont6x12.obj,tgdFont6x13.obj,tgdFont6x13bold.obj,tgdFont6x9.obj
FONT3O   = tgdFont7x13.obj,tgdFont7x13bold.obj,tgdFont7x14.obj,tgdFont8x13.obj
FONT4O   = tgdFont8x13bold.obj,tgdFont8x16.obj,tgdFont9x15.obj,tgdFont9x15bold.obj
FONTSO   = $(FONT1O),$(FONT2O),$(FONT3O),$(FONT4O)
OBJ      = tgd.obj,tgdgd.obj,tgdcommand.obj,$(FONTSO)

all : $(PROG)

$(PROG) : $(OBJ),$(GDLIB)
          LINK/EXE=TGD $(OBJ),$(GDLIB)/LIBRARY

$(GDLIB) :
        old_default = F$ENVIRONMENT("DEFAULT")
	SET DEFAULT $(GDHOME)
        MMK
        SET DEFAULT 'old_default'
