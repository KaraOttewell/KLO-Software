#Depending on your system, you will need to modify this makefile.

#If you do not have gcc, change the setting for CC, but you must
#use an ANSI standard C compiler (NOT the old SunOS 4.1.3 cc
#compiler; get gcc if you are still using it). 

#If the ar command fails on your system, consult the ar manpage
#for your system. 

CC = CC/PREFIX=ALL/DEBUG/NOOPTIMIZE
LINK = LINK/NODEBUG
AR = LIBRARY/INSERT

all : gddemo.exe,giftogd.exe,webgif.exe
      ! Done

gddemo.exe : gddemo.obj,libgd.olb,gd.h,gdfonts.h,gdfontl.h
	$(CC) gddemo
        $(LINK) gddemo,libgd/LIBRARY

giftogd.exe : giftogd.obj,libgd.olb,gd.h
	$(CC) giftogd
        $(LINK) giftogd,libgd/LIBRARY

libgd.olb : gd.obj,gdfontt.obj,gdfonts.obj,gdfontmb.obj,gdfontl.obj,gdfontg.obj,\
	gd.h,gdfontt.h,gdfonts.h,gdfontmb.h,gdfontl.h,gdfontg.h
	IF F$SEARCH("libgd.olb;").NES."" THEN $ DELETE/LOG libgd.olb;
        LIBRARY/CREATE libgd
	$(AR)	libgd gd.obj,gdfontt.obj,gdfonts.obj,gdfontmb.obj,\
		gdfontl.obj,gdfontg.obj

webgif.exe : webgif.obj,libgd.olb,gd.h
	$(CC) webgif
        $(LINK) webgif,libgd/LIBRARY

clean :
	DELETE/LOG *.obj;
