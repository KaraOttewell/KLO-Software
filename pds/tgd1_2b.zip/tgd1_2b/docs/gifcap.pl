#!/usr/local/bin/perl
#
#	A quick reverse engineering of Doug Bigwood's
#	program `gifcaptn' which you can read about at:
#	    http://probe.nalusda.gov:8000/tools/aboutgifcaptn.html
#
#	Bradley K. Sherman 1995
#



@fontlist = (
  gdFont5x8, gdFont6x10, gdFont6x12, gdFont6x13,
  gdFont6x13bold, gdFont6x9, gdFont7x13, gdFont7x13bold,
  gdFont7x14, gdFont8x13, gdFont8x13bold, gdFont8x16,
  gdFont9x15, gdFont9x15bold, gdFont10x20, gdFont12x24,
  gdFontLarge, gdFontSmall
);

@fontheight = (
 8, 10, 12, 13,
 13, 9, 13, 13, 
 14, 13, 13, 16,
 15, 15, 20, 24,
 16, 12
);

&check_command_line();               # Process the command line;
&get_image_size();                   # How big is the input image?
&create_captioned_image();           # Copy, caption and write.

exit;

# ------------------------------------------------------------- #
# --
#  Cursory check and interpretation of command line
sub check_command_line{
	$fg = "0:0:0";
	$bg = "255:255:255";
	$argc = $#ARGV + 1;
	if ($argc != 6  &&  $argc != 4) {&usage()};
	$infile = $ARGV[0];
	$outfile = $ARGV[1];
	$fontnumber = $ARGV[2];
	$text = $ARGV[3];
	if ($argc > 4 ) {
		$fg = $ARGV[4];
		$bg = $ARGV[5];
	}
	if ($fontnumber < 0  ||  $fontnumber > 17) {
		print "illegal font $fontnumber/n";
		&usage();
	}
	($fgr, $fgg, $fgb) = split( /:/, $fg );
	($bgr, $bgg, $bgb) = split( /:/, $bg );
	$fontname = $fontlist[$fontnumber];
	$fonty = $fontheight[$fontnumber];
	}


# --
# Tell user what her options are
sub usage {
	print "Usage: gifcap in_file out_file font_number";
	print " text [fg_color] [bg_color]\n";
	print "NOTE: fg and bg colors must have the form rrr:ggg:bbb\n";
	print "\t(i.e. red, green, and blue values).\n";
	print "All color values must have 3 digits and be between";
	print " 0 and 255, e.g. 000:255:010\n";
	print "The default foreground color is white, the default";
	print " background color is black.\n";

	print "The font_numbers and fonts are:\n";
	print "\t0  5x8\n\t1  6x10\n\t2  6x12\n";
	print "\t3  6x13\n\t4  6x13bold\n\t5  6x9\n";
	print "\t6  7x13 \n\t7  7x13bold\n\t8  7x14\n";
	print "\t9  8x13 \n\t10 8x13bold \n\t11 8x16\n";
	print "\t12 9x15 \n\t13 9x15bold \n\t14 10x20\n";
	print "\t15 12x24\n\t16 gdFontLarge \n\t17 gdFontSmall\n";
	exit;
}

# --
# We need to know size of input image to set up 
# captioned output image.
sub get_image_size {
	# Find X, Y size of image
	# This is done by having tgd write to a temporary file 
	# and then reading the temp file.
	open( TGD, "| tgd > /tmp/rpt$$" );
	print TGD "createfromgif myim $infile\n";
	print TGD "sx myim\n";
	print TGD "sy myim\n";
	close( TGD );
	open( RPT, "/tmp/rpt$$" );
	$infile_x = <RPT>;
	chop $infile_x;
	$infile_y = <RPT>;
	chop $infile_y;
	close( RPT );
	unlink( "/tmp/rpt$$" );
}

# --
# Copy and caption and write out.
sub create_captioned_image {
	$newy = $infile_y + $fonty + 1;
	$capx = int($infile_x / 2);
	$capy = $infile_y + int($fonty / 2);
	
	open( TGD, "| tgd" );
	print TGD "createfromgif myim $infile\n";
	print TGD "create cap $infile_x $newy\n";
	print TGD "colorallocate cap bg $bgr $bgg $bgb\n";
	print TGD "colorallocate cap fg $fgr $fgg $fgb\n";
	print TGD "copy cap myim 0 0 0 0 $infile_x $infile_y\n";
	print TGD "stringcenter cap $fontname $capx $capy \"$text\" fg\n";
	print TGD "gif cap $outfile\n";
	close( TGD );
}
