#!/usr/local/bin/perl
open( TGD, "| tgd" );
print TGD "create myimage 200 100\n";
print TGD "colorallocate myimage white 255 255 255\n";
print TGD "colorallocate myimage black 0 0 0\n";
print TGD "string myimage gdFontLarge 40 40 \"hello, world!\" black\n";
print TGD "gif myimage helloworld.gif\n";
