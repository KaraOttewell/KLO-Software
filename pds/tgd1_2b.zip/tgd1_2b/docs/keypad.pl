#!/usr/local/bin/perl

$defaulturl = "http://s27w007.pswfs.gov/";
$fontname   = "gdFont8x16";
$fontwidth  = 8;
$fontheight = 16;
$inpfile    = "keypad.inp";
$image      = "keypad";
$imgmapfile = "keypad.map";
$htmlfile   = "keypad.html";
$tgd        = "tgd";
$ROOT       = "phil";

open( INP, "keypad.inp" );

$count = 0;
while( <INP> )  {
	($label,$url)   = split(/\t/);
	chop( $url );
	$labels[$count] = $label;
	$urls[$count]   = $url;
	++$count;
}
die( "There should be exactly 12 input lines.\n" ) if ( $count != 12 );
close( INP );

open( CONF, "> $imgmapfile"  );
open( TGD,  "| $tgd"  );
print CONF "$defaulturl\n";
&initimage();
&button( $image, 10, 10, 110, 60, $labels[0], $urls[0] );
&button( $image, 10, 70, 110, 120, $labels[1], $urls[1] );
&button( $image, 10, 130, 110, 180, $labels[2], $urls[2] );
&button( $image, 10, 190, 110, 240, $labels[3], $urls[3] );
&button( $image, 130, 10, 230, 60, $labels[4], $urls[4] );
&button( $image, 130, 70, 230, 120, $labels[5], $urls[5] );
&button( $image, 130, 130, 230, 180, $labels[6], $urls[6] );
&button( $image, 130, 190, 230, 240, $labels[7], $urls[7] );
&button( $image, 240, 10, 340, 60, $labels[8], $urls[8] );
&button( $image, 240, 70, 340, 120, $labels[9], $urls[9] );
&button( $image, 240, 130, 340, 180, $labels[10], $urls[10] );
&button( $image, 240, 190, 340, 240, $labels[11], $urls[11] );
print TGD "interlace $image 1\n";
print TGD "gif $image $image.gif\n";
print TGD "destroy $image\n";
close(TGD);
close(CONF);

open( HTML, "> $htmlfile" );
&makehtml();
close(HTML);

#	button (imagehandle , x1, y1, x2, y2, label, url );
#	Draw a 3-D button, label it in the center and
#	write out the coordinates to the imagemap file.
sub button {
	local( $url) = pop(@_);
	local( $label) = pop(@_);
	local( $y2 ) = pop(@_);
	local( $x2 ) = pop(@_);
	local( $y1 ) = pop(@_);
	local( $x1 ) = pop(@_);
	local( $imagename ) = pop(@_);
	print TGD "line $imagename $x1 $y1 $x2 $y1 white\n";
	print TGD "line $imagename $x1 $y1 $x1 $y2 white\n";
	print TGD "line $imagename $x2 $y2 $x2 $y1 black\n";
	print TGD "line $imagename $x2 $y2 $x1 $y2 black\n";

#	$strlen = length($label) * $fontwidth;
#	$maxlen = ($x2 - $x1) - 2; # 2 for button edges
#	die( "string too long " ) if $strlen > $maxlen;
	$cx = int(($x1 + $x2) / 2);
	$cy = int( ($y1 + $y2) / 2);

	print TGD "stringcenter $imagename $fontname $cx $cy \"$label\" black\n";
	print CONF "rect $url $x1,$y1 $x2,$y2\n";

}

#	initimage()
#	Initialize image
sub initimage {
    print TGD "create $image 350 250\n";
    print TGD "colorallocate $image grey    192 192 192\n";
    print TGD "colorallocate $image white   255 255 255\n";
    print TGD "colorallocate $image black   000 000 000\n";
    print TGD "colortransparent $image grey\n";
}

#	makehtml()
#	Write out an HTML file 
sub makehtml {
print HTML "<head>\n";
print HTML "<title>keypad</title>\n";
print HTML "</head>\n";
print HTML "<body>\n";
print HTML "<a href=\"http://$ROOT/cgi-bin/imagemap/tgd/keypad.map\">\n";
print HTML "<img src=\"keypad.gif\" ISMAP>\n";
print HTML "<hr>\n";
print HTML "<h1>Keypad</h1>\n";
print HTML "</a>\n";
print HTML "</body>\n";
}
