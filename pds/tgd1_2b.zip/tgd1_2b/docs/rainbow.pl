#!/usr/local/bin/perl
#
#	rainbow.pl
#
#	To run:
#		rainbow.pl | tgd
#
#	Output:
#		a GIF format image file named rainbow.gif
#
#	Bradley K. Sherman (bks@netcom.com) 6/95
#

print "create mybrush 20 20\n";
print "colorallocate mybrush grey    192 192 192\n";
print "colorallocate mybrush white   255 255 255\n";
print "colorallocate mybrush black     0   0   0\n";
print "colorallocate mybrush red     255   0   0\n";
print "colorallocate mybrush orange  255 127   0\n";
print "colorallocate mybrush yellow  255 255   0\n";
print "colorallocate mybrush green     0 255   0\n";
print "colorallocate mybrush blue      0   0 255\n";
print "colorallocate mybrush indigo  127   0 255\n";
print "colorallocate mybrush violet  255   0 255\n";
print "colortransparent mybrush grey\n";

# Perl is ugly to purists, I'm sure
@bow = (violet, indigo, green, blue, yellow, orange, red);
print "create rainbow 300 150\n";
for ( $count = 0; $count < 7; $count++ ) {
	print "arc mybrush 10 10 10 10 0 360 $bow[$count]\n";
	print "filltoborder mybrush 10 10 $bow[$count] $bow[$count]\n";
	print "setbrush rainbow mybrush\n";
	$wid = ($count * 20) + 100;
	$hei = ($count * 20) + 100;
	print "arc rainbow 150 150 $wid $hei 180 360 gdbrushed\n";
}

print "gif rainbow rainbow.gif\n";
