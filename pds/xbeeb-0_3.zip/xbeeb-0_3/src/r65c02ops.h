/*
 * Copyright (c) James Fidell 1995, 1996.
 *
 * Permission to use, copy, modify, distribute, and sell this software
 * and its documentation for any purpose is hereby granted without fee,
 * provided that the above copyright notice appear in all copies and
 * that both that copyright notice and this permission notice appear in
 * supporting documentation, and that the name of the copyright holder
 * not be used in advertising or publicity pertaining to distribution
 * of the software without specific, written prior permission. The
 * copyright holder makes no representations about the suitability of
 * this software for any purpose. It is provided "as is" without express
 * or implied warranty.
 *
 * THE COPYRIGHT HOLDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS
 * SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS, IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
 * SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
 * RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
 * CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
 * CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */


#ifndef	OPS65c02_H
#define	OPS65c02_H

#define	op_RMB0		0x07
#define	op_RMB1		0x17
#define	op_RMB2		0x27
#define	op_RMB3		0x37
#define	op_RMB4		0x47
#define	op_RMB5		0x57
#define	op_RMB6		0x67
#define	op_RMB7		0x77

#define	op_SMB0		0x87
#define	op_SMB1		0x97
#define	op_SMB2		0xa7
#define	op_SMB3		0xb7
#define	op_SMB4		0xc7
#define	op_SMB5		0xd7
#define	op_SMB6		0xe7
#define	op_SMB7		0xf7

#endif	/* OPS65c02_H */
