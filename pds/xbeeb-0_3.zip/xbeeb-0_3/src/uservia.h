/*
 * Copyright (c) James Fidell 1994, 1995, 1996.
 *
 * Permission to use, copy, modify, distribute, and sell this software
 * and its documentation for any purpose is hereby granted without fee,
 * provided that the above copyright notice appear in all copies and
 * that both that copyright notice and this permission notice appear in
 * supporting documentation, and that the name of the copyright holder
 * not be used in advertising or publicity pertaining to distribution
 * of the software without specific, written prior permission. The
 * copyright holder makes no representations about the suitability of
 * this software for any purpose. It is provided "as is" without express
 * or implied warranty.
 *
 * THE COPYRIGHT HOLDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS
 * SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS, IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
 * SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
 * RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
 * CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
 * CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */


#ifndef	USERVIA_H
#define	USERVIA_H

#include "6522Via.h"

extern  void			ResetUserVia();
extern  byteval			ReadUserVia ( int );
extern  void			WriteUserVia ( int, byteval );
extern	void			UserViaSetInterrupt ( byteval );
extern	void			UserViaClearInterrupt ( byteval );
extern	void			UserViaSetPortAPinLevel ( byteval );
extern	void			UserViaSetPortBPinLevel ( byteval );

extern	int				SaveUserVia ( int );
extern	int				RestoreUserVia ( int, unsigned int );

extern	int				UserViaTimer1;
extern	int				UserViaTimer2;
extern	unsigned char	UserViaTimer2InterruptEnable;
extern	unsigned char	UserViaTimer1Continuous;
extern	unsigned char	UserViaTimer1SetPB7;
extern	unsigned char	UserViaTimer2PulseCount;
extern	byteval			UserViaPortAPinLevel;
extern	byteval			UserViaPortBPinLevel;
extern	Via				UserVia;


#define	UserViaCheckInterrupt(x)	( UserVia [ IFR ] & x )

#endif	/* USERVIA_H */
