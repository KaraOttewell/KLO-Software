/* Use only ANSI file system calls */
#include <stdio.h>
#include <stdlib.h>

int main( int argc, char *argv[] )
{
	FILE *infile, *outfile;
	unsigned char x[ 16384 ];
        size_t nbytes;

#ifndef VMS
	infile = fopen("OS1.2.rom","rb");
	outfile = fopen("OS1.2p1.rom","wb");
#else
	infile = fopen("OS1_2.rom","rb");
	outfile = fopen("OS1_2p1.rom","wb");
#endif
	nbytes = fread ( x, 1, sizeof(x), infile );
	fclose ( infile );

	/*
	 * The OSFILE trap
	 */

	x [ 0x327d ] = 0x22;

	/*
	 * The OSFSC trap
	 */

	x [ 0x31b1 ] = 0x02;

	nbytes = fwrite ( x, 1, sizeof(x), outfile );
	fclose ( outfile );
	exit(EXIT_SUCCESS);
}
