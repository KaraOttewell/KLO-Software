# VMS make file for use with MMS or MMK (public domain MMS-alike)
#
# Use to make the VMS version of WHOIS
# by Phil Ottewell <phil@XZYpottsoft_REMOVEXYZ.com> 12-Aug-1997
#
# Assumes DEC C and VMS >= 6.x
#
# Using MMK on VAX or Alpha:  MMK
# Using MMS on VAX or Alpha:  MMS
# 
#   VAX executable is WHOIS.EXE
# Alpha executable is WHOIS.EXE_ALPHA
# 
ALPHA_IS_ALPHA = 1
.ifdef $(MMS$ARCH_NAME)_IS_ALPHA
__ALPHA__ = 1
.endif
.IFDEF __ALPHA__
EXE_TYPE = EXE_ALPHA
OBJ_TYPE = OBJ_ALPHA
.ELSE
EXE_TYPE = EXE
OBJ_TYPE = OBJ
.ENDIF
#CDEBUG = /DEBUG/NOOPT
#LDEBUG = /DEBUG
CDEBUG = 
LDEBUG = 

# Use plain CC in case user already has a CC symbol that might conflict
CC = CC
CFLAGS = /PREFIX=ALL/OBJECT=$(MMS$TARGET)$(CDEBUG)

.SUFFIXES :                     !Override the default rules
.SUFFIXES :     .$(EXE_TYPE) .$(OBJ_TYPE) .C

.C.$(OBJ_TYPE) :
  @ WRITE SYS$OUTPUT "Compiling: $(MMS$SOURCE) -> $(MMS$TARGET)"
  @ $(CC)$(CFLAGS)$(CDEBUG) $(MMS$SOURCE)

all : whois$(EXE_TYPE)
  @ WRITE SYS$OUTPUT "Do @SETUP to create the WHOIS foreign command"

whois$(EXE_TYPE) : whois.$(OBJ_TYPE)
  @ WRITE SYS$OUTPUT "Linking: WHOIS.$(OBJ_TYPE) -> WHOIS.$(EXE_TYPE)"
  @ LINK/EXECUTABLE=whois.$(EXE_TYPE) whois.$(OBJ_TYPE)$(LDEBUG)
  @ WRITE SYS$OUTPUT "Created WHOIS.$(EXE_TYPE)"

clean :
  @ WRITE SYS$OUTPUT "Deleting: WHOIS.$(OBJ_TYPE);* and WHOIS.$(EXE_TYPE);*"
  @ IF F$SEARCH("whois.$(OBJ_TYPE)").NES."" THEN $ DELETE whois.$(OBJ_TYPE);*
  @ IF F$SEARCH("whois.$(EXE_TYPE)").NES."" THEN $ DELETE whois.$(EXE_TYPE);*
