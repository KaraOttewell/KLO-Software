$! A VMS Command procedure to make WHOIS for VMS VAX and Alpha
$!
$! Phil Ottewell <phil@XZYpottsoft_REMOVEXYZ.com> 12-Aug-1997
$!               http://www.pottsoft.com/home/pds/pds.html
$!
$ is_alpha = F$EXTRACT(0,4,F$GETSYI("NODE_HWTYPE")).EQS."ALPH"
$ IF is_alpha
$ THEN
$   obj = "OBJ_ALPHA"
$   exe = "EXE_ALPHA"
$ ELSE
$   obj = "OBJ"
$   exe = "EXE"
$ ENDIF
$!
$ IF P1.EQS."D"
$ THEN
$   WRITE SYS$OUTPUT "DEBUG version"
$   copt = "/DEBUG/NOOPTIMIZE"
$   lopt = "/DEBUG"
$ ELSE
$   copt = ""
$   lopt = ""
$ ENDIF
$!
$ this_path = F$ELEMENT (0, "]", F$ENVIRONMENT ("PROCEDURE")) + "]"
$!
$ WRITE SYS$OUTPUT "All output is in ''this_path'"
$ WRITE SYS$OUTPUT "Compiling: WHOIS.C -> WHOIS.''obj'"
$ CC'copt'/PREFIX=ALL/OBJECT='this_path'WHOIS.'obj' 'this_path'WHOIS
$ WRITE SYS$OUTPUT "Linking: WHOIS.''obj' -> WHOIS.''exe'"
$ LINK'lopt'/EXECUTABLE='this_path'WHOIS.'exe' 'this_path'WHOIS.'obj'
$! There now, that wasn't too hard was it ?
$ WRITE SYS$OUTPUT "Created WHOIS.''exe'"
$!
$ @'this_path'SETUP VERBOSE
$!
$ EXIT
