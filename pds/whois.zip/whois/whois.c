/*----------------------------------------------------------------------------*/
/* V01-002	�Phil Ottewell,	phil@XZYpottsoft_REMOVEXYZ.com	   25-Mar-2002*/
/*			http://www.pottsoft.com/pds/pds.html                  */
/*              Add automatic second attempt to look up on server recommended */
/*              by first server, if any.                                      */
/*                                                                            */
/* V01-001	�Phil Ottewell,	phil@pottsoft.XYZdemon_NOXZY.co.uk 13-Aug-1997*/
/*			http://www.yrl.co.uk/~phil/pds/pds.html               */
/*              First attempt.                                                */
/*----------------------------------------------------------------------------*/
/*                                                                            */
/* WHOIS client for VMS and Windows NT                                        */
/*                                                                            */
/* Usage: whois [ -h nic_server_to_use ] domain_to_find [ > output_file ]              */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* ANSI C Headers */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

/* Sockets Headers */
#ifdef _WIN32
# include <winsock2.h>
# pragma comment(lib,"ws2_32.lib")
#else
# include <in.h>
# include <netdb.h>
# include <inet.h>
# include <unixio.h>
# define closesocket close
#endif

# ifdef __VMS
/* Map "how" codes for shutdown() on VMS so we can use same constants as NT */
/* The SHUT_xxx constants are #define-d in sockets.h under VMS */
#  define SD_RECEIVE SHUT_RD    /* Disables further receive operations */
#  define SD_SEND    SHUT_WR    /* Disables further send operations */
#  define SD_BOTH    SHUT_RDWR  /* Disables further send and receive ops. */
# endif /* # ifdef __VMS */

/* Function Prototypes */
int iInitializeSocketLibrary( void );
int iShutdownSocketLibrary( void );
int iDoWhoisLookup( int argc, char *argv[] );
int iReadResponse(int iSocketFD, char **ppReturnBuf);
int iMatchRight(const char *string, const char *right_part );

/* Macro definitions */
/* MIN and MAX get defined vis <sys/types.h> on Unix */
#define MIN(a,b) (((a)<(b))?(a):(b))
#define MAX(a,b) (((a)>(b))?(a):(b))

/* Global static values */
char *rgszServerList[] = {
"whois.berkeley.edu                 University of California at Berkeley C=US",
"www.binghamton.edu                 State University of New York at Binghamton C=US",
"finger.caltech.edu                 California Institute of Technology C=US",
"csufresno.edu                      California State University - Fresno C=US",
"csuhayward.edu                     California State University - Hayward C=US",
"csus.edu                           California State University - Sacramento C=US",
"whois.cwru.edu                     Case Western Reserve University C=US",
"cc.fsu.edu                         Florida State University C=US",
"gettysburg.edu                     Gettysburg College C=US",
"gmu.edu                            George Mason University C=US",
"whois.dfci.harvard.edu             Dana-Farber Cancer Institute C=US",
"hmc.edu                            Harvey Mudd College C=US",
"indiana.edu                        Indiana University C=US",
"nii.isi.edu                        US Domain Registry C=US",
"whois.messiah.edu                  Messiah College C=US",
"whois.rsmas.miami.edu              University of Miami, Rosentiel School of Marine and Atmospheric Sciences C=US",
"mit.edu                            Massachusetts Institute of Technology C=US",
"directory.msstate.edu              Mississippi State University C=US",
"vax2.winona.msus.edu               Minnesota State University - Winona C=US",
"info.nau.edu                       Northern Arizona University C=US",
"whois.ncsu.edu                     North Carolina State University C=US",
"nd.edu                             University of Notre Dame C=US",
"earth.njit.edu                     New Jersey Institute of Technology C=US",
"vm1.nodak.edu                      North Dakota State University C=US",
"austin.onu.edu                     Ohio Northern University C=US",
"ph.orst.edu                        Oregon State University C=US",
"osu.edu                            Ohio State University C=US",
"whois.oxy.edu                      Occidental College C=US",
"info.psu.edu                       Pennsylvania State University C=US",
"whois.cc.rochester.edu             University of Rochester C=US",
"whitepages.rutgers.edu             Rutgers University C=US",
"whois.sdsu.edu                     San Diego State University C=US",
"stanford.edu                       Stanford University C=US",
"camis.stanford.edu                 Stanford University C=US",
"whois.slac.stanford.edu            Stanford Linear Accelerator Center C=US",
"stjohns.edu                        St. John\'s University C=US", 
"sunysb.edu                         State University of New York, Stony Brook C=US",
"whois.bcm.tmc.edu                  Baylor College of Medicine C=US",
"whois.ubalt.edu                    University of Baltimore C=US",
"directory.ucdavis.edu              University of California at Davis C=US",
"uchicago.edu                       University of Chicago C=US",
"ucsd.edu                           University of California at San Diego C=US",
"weber.ucsd.edu                     University of California at San Diego, Division of Social Sciences C=US",
"cgl.ucsf.edu                       University of California at San Francisco, School of Pharmacy C=US",
"whois.uh.edu                       University of Houston C=US",
"whois.umass.edu                    University of Massachusetts at Amherst C=US",
"lookup.umd.edu                     University of Maryland C=US",
"umn.edu                            University of Minnesota C=US",
"ns.unl.edu                         University of Nebraska at Lincoln C=US",
"whois.upenn.edu                    University of Pennsylvania C=US",
"x500.utexas.edu                    University of Texas at Austin C=US",
"netlib2.cs.utk.edu                 na-net (linear algebra on computers) C=US",
"whois.virginia.edu                 University of Virginia C=US",
"whois.wfu.edu                      Wake Forest University C=US",
"wisc.edu                           University of Wisconsin C=US",
"wpi.wpi.edu                        Worcester Polytechnic Institute C=US",
"ibc.wustl.edu                      Washington University C=US",
"vm1.hqadmin.doe.gov                U.S. Department of Energy Headquarters C=US",
"wp.doe.gov                         U.S. Department of Energy C=US",
"llnl.gov                           Lawrence Livermore National Laboratory C=US",
"x500.arc.nasa.gov                  NASA Ames Research Center C=US",
"x500.gsfc.nasa.gov                 NASA Goddard Space Flight Center C=US",
"larc.nasa.gov                      NASA Langley Research Center C=US",
"wp.nersc.gov                       National Energy Research Supercomputer Center C=US",
"seda.sandia.gov                    Sandia National Laboratories C=US",
"whois.nic.ddn.mil                  DoD Network Information Center (Department of Defense and Military only) C=US",
"whois.nrl.navy.mil                 Naval Research Laboratory C=US",
"whois.internic.net                 Network Solutions, Inc. C=US",
"whois.lac.net                      Latin America & Caribbean Whois Server C=EC",
"whois.ripe.net                     Reseaux IP Europeens C=NL",
"whois.morris.org                   Morris Automated Information Network C=US",
"whois.risc.uni-linz.ac.at          Research Institute for Symbolic Computation, University of Linz C=AT",
"archie.au                          Australian Academic and Research Network C=AU",
"whois.adelaide.edu.au              University of Adelaide C=AU",
"whois.monash.edu.au                Monash University C=AU",
"uwa.edu.au                         University of Western Australia C=AU",
"sserve.cc.adfa.oz.au               University College, Australian Defense Force Academy C=AU",
"whois.kuleuven.ac.be               Katholieke Universiteit Leuven C=BE",
"whois.belnet.be                    Belgian National Research Network C=BE",
"whois.camosun.bc.ca                Camosun College, Victoria, B.C. C=CA",
"whois.queensu.ca                   Queen\'s University, Kingston, Canada C=CA",
"ac.nsac.ns.ca                      Nova Scotia Agricultural College C=CA",
"whois.unb.ca                       University of New Brunswick C=CA",
"panda1.uottawa.ca                  University of Ottawa C=CA",
"dvinci.usask.ca                    University of Saskatchewan, Engineering C=CA",
"whois.usask.ca                     University of Saskatchewan C=CA",
"phys.uvic.ca                       University of Victoria, Physics & Astronomy C=CA",
"whois.uwo.ca                       University of Western Ontario C=CA",
"whois.nic.ch                       SWITCH Swiss Academic and Research Network C=CH",
"whois.ci.ucr.ac.cr                 University of Costa Rica Computer Center C=CR",
"whois.cuni.cz                      Charles University, Prague C=CZ",
"whois.mff.cuni.cz                  Charles University, Faculty of Mathematics and Physics C=CZ",
"whois.vutbr.cz                     Technical University of Brno C=CZ",
"whois.fh-koeln.de                  Fachhochschule Koeln C=DE",
"whois.fzi.de                       Forschungszentrum Informatik C=DE",
"hermes.informatik.htw-zittau.de    HTW Zittau/Goerlitz Elektrotechnik/Informatik C=DE",
"whois.th-darmstadt.de              Darmstadt University of Technology C=DE",
"whois.tu-chemnitz.de               Technische Universitaet Chemnitz C=DE",
"whois.uni-regensburg.de            Universitaet Regensburg C=DE",
"whois.uni-c.dk                     Danish Computing Centre for Research and Education C=DK",
"whois.eunet.es                     EUnet, Goya, Spain C=ES",
"whois.dit.upm.es                   Tech. Univ. Madrid, Telecommunications Highschool C=ES",
"cs.hut.fi                          Helsinki University of Technology C=FI",
"oulu.fi                            Oulu University C=FI",
"vtt.fi                             Technical Research Centre of Finland C=FI",
"whois.nic.fr                       France C=FR",
"isgate.is                          Association of Research Networks in Iceland C=IS",
"dsa.nis.garr.it                    GARR-NIS c/o CNR-CNUCE C=IT",
"whois.nis.garr.it                  GARR-NIS c/o CNR-CNUCE C=IT",
"whois.nic.mx                       Network Information Center - Mexico C=MX",
"whois-server.l.chiba-u.ac.jp       Chiba University C=JP",
"whois.cc.keio.ac.jp                Keio University C=JP",
"whois.cc.uec.ac.jp                 University of Electro-Communications C=JP",
"whois.nic.ad.jp                    Japan Network Information Center C=JP",
"whois.nic.li                       SWITCH Swiss Academic and Research Network C=LI",
"whois.canterbury.ac.nz             University of Canterbury C=NZ",
"directory.vuw.ac.nz                Victoria University, Wellington C=NZ",
"waikato.ac.nz                      Waikato University C=NZ",
"whois.elka.pw.edu.pl               Faculty of Electronic Engineering, Warsaw University of Technology C=PL",
"whois.ia.pw.edu.pl                 Institute of Automatic Control, Warsaw University of Technology C=PL",
"whois.nic-se.se                    NIC Sweden C=SE",
"whois.uakom.sk                     SANET (WAN of Slovak academic institutions) C=SK",
"whois.nic.uk                         Nominet UK (.UK Domain Registrar) C=GB",
"whois.state.ct.us                  Department of Administrative Services, State of Connecticut C=US",
"info.cnri.reston.va.us             Corporation for National Research Initiatives, Knowbot interface C=US",
"whois.und.ac.za                    University of Natal (Durban) C=ZA"
};

/*--- Main program starts here -----------------------------------------------*/
int main( int argc, char *argv[] )
{
    int iReturnValue = EXIT_FAILURE;
/*  End of declarations ... */

/*  VMS DCL doesn't use > for redirecting output so fake it by pre-checking */
/*  command line for > . This is cleaner than redirecting SYS$OUTPUT - PJO */
    if ( argc > 2 && !strcmp(argv[argc-2],">")) {
      if ( freopen( argv[argc-1], "w", stdout) ) {
        fprintf(stderr,"Sending output to %s\n",argv[argc-1]);
      }
/*    Remove the "> file" from end so it's not parsed by next bit */
      argc -= 2;
    }

    iReturnValue = iDoWhoisLookup( argc, argv );

    return( iReturnValue );
}

int iDoWhoisLookup( int argc, char *argv[] )
{
    const short int kiWhoisPortNumber = 43; /* Standard WHOIS service port number */
    int iAttempt = 0;
    int iSocketFD = 0;
    int iReturnValue = EXIT_FAILURE;
    int iLastDotPosition = 0;
    int iServerNameLength = 0;
    int iDomainNameLength = 0;
    int i = 0;
    int fFoundBetterWhoisServer = 0;
    int iRecommendedServerStringLength = 0;
    const int kiMaxDifferentServerAttempts = 2;
    const char* kszWhoisServerIdentificationPrefix = "Whois Server: ";
    char *pszResultString = NULL;
    char *pszPointerToNullTerminator = NULL;
    char *pszPointerToRecommendedWhoisServer = NULL;
    char *pszPointerToNextCRLF = NULL;
    char *pszPointerToNextLF = NULL;
    char *pszPointerToNextSpace = NULL;
    char *pszWhoisServer = NULL;
    char *pszDomainToFind = NULL;
    char *pszRightMostBit = NULL;
    struct sockaddr_in sinSocket;
    struct hostent *pheHost;
    char *pszRequestBuffer = NULL;
/*  End of declarations ... */

/*  Initialize sockets library */
    iReturnValue = iInitializeSocketLibrary();

    if ( argc == 4  &&   strcmp( argv[1], "-h") == 0) {
      iServerNameLength = strlen(argv[2]);
      pszWhoisServer = calloc(iServerNameLength+1,1);
      if ( pszWhoisServer == NULL )
      {
        perror( "whois: unable to allocate memory for server name");
        exit(EXIT_FAILURE);
      }
      strcpy(pszWhoisServer,argv[2]);

      iDomainNameLength = strlen(argv[3]);
      pszDomainToFind = calloc(iDomainNameLength+1,1);
      if ( pszDomainToFind == NULL )
      {
        perror( "whois: unable to allocate memory for domain name to find");
        exit(EXIT_FAILURE);
      }
      strcpy(pszDomainToFind,argv[3]);
    } else if ( argc == 2 ) {
      iDomainNameLength = strlen(argv[1]);
      pszDomainToFind = calloc(iDomainNameLength+1,1);
      if ( pszDomainToFind == NULL )
      {
        perror( "whois: unable to allocate memory for domain name to find");
        exit(EXIT_FAILURE);
      }
      strcpy(pszDomainToFind,argv[1]);
    } else {
      fprintf(stderr, "Usage: whois [ -h nic_server_to_use ] domain_to_find");
#ifdef __VMS
      fprintf(stderr, " [ > output_file ]");
#endif /* # ifdef __VMS */
      fprintf(stderr, "\n\n");
      fprintf(stderr, "For a list of whois servers try: whois -h whois.indiana.edu whois-servers\n");
      exit( EXIT_SUCCESS );
    }

    /* User lower case version for comparisons */
    for ( i = 0; pszDomainToFind[i] != '\0'; ++i)
    {
      pszDomainToFind[i] = tolower(pszDomainToFind[i]);
    }

/*  If server not explicitly specified on command try to choose a sensible one*/
    if ( !pszWhoisServer )
    {
      pszRightMostBit = strrchr(pszDomainToFind, '.');
        
      if ( pszRightMostBit != NULL )
      {
        iLastDotPosition = (int)(pszRightMostBit - pszDomainToFind);
      }
          
      if ( iLastDotPosition > 0  &&  iLastDotPosition < iDomainNameLength-1 )
      {
        if ( strcmp(pszRightMostBit,".com") == 0 )
        {
          // Use internic for a .com lookup
          iServerNameLength = strlen("whois.internic.net");
          pszWhoisServer = calloc(iServerNameLength+1,1);
          if ( pszWhoisServer == NULL )
          {
            perror( "whois: unable to allocate memory for server name");
            exit(EXIT_FAILURE);
          }
          strcpy(pszWhoisServer,"whois.internic.net");
        }
        else
        {
          for (i = 0; i < sizeof(rgszServerList)/sizeof(rgszServerList[0]); ++i)
          {
            char *pszServerNameEnd = strchr(rgszServerList[i],' ');
            iServerNameLength = (pszServerNameEnd-rgszServerList[i]);
            pszWhoisServer = calloc(iServerNameLength+1,1);
            if ( pszWhoisServer == NULL )
            {
              perror( "whois: unable to allocate memory for server name");
              exit(EXIT_FAILURE);
            }
            strncpy(pszWhoisServer,rgszServerList[i],iServerNameLength);

            if ( strstr(pszWhoisServer,pszRightMostBit) != NULL )
            {
              break;
            }
            else
            {
              free(pszWhoisServer);
            }

          }

        }

      }

    }

    /* Try the lookup, switching to recommended server if there is one */
    for ( iAttempt = 0; iAttempt < kiMaxDifferentServerAttempts; ++iAttempt )
    {
      /* Get pointer to network data struct for remote server */
      pheHost = gethostbyname(pszWhoisServer);
      if ( !pheHost )
      {
        fprintf(stderr, "whois: %s: nic server unknown\n", pszWhoisServer);
        exit( EXIT_FAILURE );
      }

      /*  char *pszActualName = pheHost->h_name; */

      /*  Open socket */
      if ( (iSocketFD = socket( AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
      {
        perror( "whois: unable to create socket");
        exit( EXIT_FAILURE );
      }

      /* Fill in the name & address structure for remote server socket */
      sinSocket.sin_family = pheHost->h_addrtype;
      sinSocket.sin_port = htons(kiWhoisPortNumber);
      memcpy( &sinSocket.sin_addr, pheHost->h_addr, pheHost->h_length);

      /* Connect to whois server */
      if ( connect(iSocketFD,(struct sockaddr *)&sinSocket,sizeof(sinSocket) )  < 0)
      {
        perror("whois: unable to connect to WHOIS server");
        perror(pszWhoisServer);
        exit( EXIT_FAILURE );
      }

      printf("Using WHOIS server %s, port %d, to find %s\n\n",
             pszWhoisServer,kiWhoisPortNumber,pszDomainToFind);

      /* Allocate buffer to hold request string */
      pszRequestBuffer = calloc(strlen(pszDomainToFind)+strlen("\r\n")+1,1);
      if ( pszRequestBuffer == NULL )
      {
        perror( "whois: unable to allocate memory for request string buffer");
        exit(EXIT_FAILURE);
      }

      strcat(pszRequestBuffer, pszDomainToFind);
      strcat(pszRequestBuffer, "\r\n");
      send( iSocketFD,  pszRequestBuffer, strlen(pszRequestBuffer), 0 );
      /* Free the request buffer and NULL out the pointer */
      free(pszRequestBuffer);
      pszRequestBuffer = NULL;

      /* Read in result string */
      if ( iReadResponse(iSocketFD,&pszResultString) > 0 )
      {
        puts(pszResultString);
      }
      else
      {
        pszResultString = "";
      }

      // If the results contains the Whois server for this domain, retry using that server
      pszPointerToRecommendedWhoisServer = strstr(pszResultString,kszWhoisServerIdentificationPrefix);

      if(pszPointerToRecommendedWhoisServer != NULL)
      {
        pszPointerToRecommendedWhoisServer += strlen(kszWhoisServerIdentificationPrefix);

        pszPointerToNullTerminator = pszPointerToRecommendedWhoisServer + strlen(pszPointerToRecommendedWhoisServer);

        pszPointerToNextCRLF = strstr(pszPointerToRecommendedWhoisServer,"\r\n");
        if ( pszPointerToNextCRLF == NULL )
        {
          pszPointerToNextCRLF = pszPointerToNullTerminator;
        }

        pszPointerToNextLF = strstr(pszPointerToRecommendedWhoisServer,"\n");
        if ( pszPointerToNextLF == NULL )
        {
          pszPointerToNextLF = pszPointerToNullTerminator;
        }

        pszPointerToNextSpace = strstr(pszPointerToRecommendedWhoisServer," ");
        if ( pszPointerToNextSpace == NULL )
        {
          pszPointerToNextSpace = pszPointerToNullTerminator;
        }

        iRecommendedServerStringLength = MIN(pszPointerToNextCRLF-pszPointerToRecommendedWhoisServer,pszPointerToNextLF-pszPointerToRecommendedWhoisServer);
        iRecommendedServerStringLength = MIN(iRecommendedServerStringLength,pszPointerToNextSpace-pszPointerToRecommendedWhoisServer);

        free(pszWhoisServer);
        pszWhoisServer = calloc(iRecommendedServerStringLength+1,1);
        if ( pszWhoisServer == NULL )
        {
          perror( "whois: unable to allocate memory for server name");
          exit(EXIT_FAILURE);
        }
        strncpy(pszWhoisServer,pszPointerToRecommendedWhoisServer,iRecommendedServerStringLength);

        fFoundBetterWhoisServer = 1;
        free(pszResultString);
      }

      if ( !fFoundBetterWhoisServer )
      {
        // If a better server isn't specified then assume that we have the information
         break;
      }
      else
      {
        fFoundBetterWhoisServer = 0;
        // Go round loop again
      }

      /* Shut down socket gracefully (other end should have done this already) */
      if ( shutdown(iSocketFD, SD_SEND) == -1)
      {
        perror ("whois: shutdown failed");
      }

      /* Close socket */
      if ( closesocket(iSocketFD) != 0 )
      {
        perror ("whois: socket close failed");
      }

    } // End of try loop

    /* Finished with domain, server and result strings so deallocate them */
    free(pszWhoisServer);
    pszWhoisServer = NULL;
    free(pszDomainToFind);
    pszDomainToFind = NULL;
    free(pszResultString);
    pszResultString = NULL;

/*  Shutdown sockets library */
    iReturnValue = iShutdownSocketLibrary();

    return( EXIT_SUCCESS );
}
/*---- Read from socket, return data in buffer, caller's job to free buffer --*/
int
iReadResponse (int iSocketFD, char **ppReturnBuf)
{
  const int ciMaxByteSize = 65535;
  char *pBuf = NULL;
  char *pTmp = NULL;
  int iStatus = 0;
  int iCount = 0; /* Bytes */
  int iTotal = 0; /* Bytes */
  int iEndOfResponse = 0;
  int iFlag = 0;      /* 0 or MSG_OOB */
  int iBufSize = 1024;
  fd_set rmask;
  fd_set wmask;
  fd_set emask;
  struct timeval tval;
  /* End of declarations ... */
  
  pBuf = calloc (iBufSize, 1);
  
  while (!iEndOfResponse)
  {
    FD_ZERO (&rmask);
    FD_ZERO (&wmask);
    FD_ZERO (&emask);
    FD_SET (iSocketFD, &rmask);
    FD_SET (iSocketFD, &emask);
    
    tval.tv_sec = 20;       /* 20 second timeout */
    tval.tv_usec = 0;
    
    /* Use select to spot incoming data and allow for timeout */
    iStatus = select (iSocketFD + 1, &rmask, &wmask, &emask, &tval);
    
    if (iStatus <= 0 || FD_ISSET (iSocketFD, &emask) || !FD_ISSET (iSocketFD, &rmask))
    {
      iEndOfResponse = 1;
      iTotal = -1;
      if (iStatus == 0)
      {
        perror("whois: timeout waiting for response from server");
      }
      
    }
    else
    {
      /* Got something to read */
      iCount = recv (iSocketFD, &pBuf[iTotal], MIN (ciMaxByteSize, (iBufSize - iTotal)), iFlag);
      if (iCount < 0)
      {
        /* Error or result of remote server closing socket after sending data */
        iEndOfResponse = 1;
      }
      else if (iCount == 0)
      {
        /* Remote server broke connection, often done after data is all sent */
        iEndOfResponse = 1;
      }
      else
      {
        iTotal += iCount;
        if (iTotal >= iBufSize)
        {
          pTmp = realloc (pBuf, iTotal + iBufSize / 2);
          if (pTmp)
          {
            pBuf = pTmp;
            /* Clear new storage space */
            (void)memset (&pBuf[iTotal], 0, iBufSize / 2);
          }
          
          iBufSize = iTotal + iBufSize / 2;
        }
        
      }
      
    }
    
  }
  
  if (iTotal >= 0)
  {
    *ppReturnBuf = pBuf;
  }
  else
  {
    free (pBuf);
    *ppReturnBuf = NULL;
  }
  
  return (iTotal);
}

/*--- Function returns 1 if right_part is at end of string, 0 otherwise ------*/
int iMatchRight( const char *string, const char *right_part )
{
    int iReturnValue = 0;
    char *pszSuffixPointer = NULL;
    size_t stPrefixLength = 0;
    size_t stStringLength = 0;
/*  End of declarations ... */

    if ( string && right_part ) {
      stStringLength = strlen( string );
      pszSuffixPointer = strstr( string, right_part );
      if ( pszSuffixPointer ) {
        stPrefixLength = pszSuffixPointer - string;
        if ( stPrefixLength + strlen(right_part) == stStringLength ) {
          iReturnValue = 1;
        }

      }

    }

    return( iReturnValue );
}

/*---- The socket initialization/shutdown functions return 0 if successful ---*/
int iInitializeSocketLibrary( void )
{
    int iStatus = 0;

//  Don't need to do this in VMS
#ifdef _WIN32
    WORD wVersionRequested;
    WSADATA wsaData;
 
    wVersionRequested = MAKEWORD( 2, 0 );
 
    iStatus = WSAStartup( wVersionRequested, &wsaData );
    if ( iStatus != 0 ) {
        /* Tell the user that we couldn't find a usable */
        /* WinSock DLL.                                  */
    }
 
    /* Confirm that the WinSock DLL supports 2.0.*/
    /* Note that if the DLL supports versions greater    */
    /* than 2.0 in addition to 2.0, it will still return */
    /* 2.0 in wVersion since that is the version we      */
    /* requested.                                        */
 
    if ( LOBYTE( wsaData.wVersion ) != 2 ||
         HIBYTE( wsaData.wVersion ) != 0 ) {
        /* Tell the user that we couldn't find a usable */
        /* WinSock DLL.                                  */
        WSACleanup( );
    }
 
/* The WinSock DLL is acceptable. Proceed. */
#endif /* #ifdef _WIN32 */

    return( iStatus );
}

int iShutdownSocketLibrary( void )
{
    int iStatus = 0;

//  Don't need to do this in VMS
#ifdef _WIN32
    iStatus = WSACleanup();
#endif /* #ifdef _WIN32 */

    return( iStatus );
}
