Whois Command Line Utility
--------------------------

Whois is a utility to look up domain registry information so that you can get 
some idea how registered a particular name, such as YRL.CO.UK or YAHOO.COM.
This is useful when researching legitimate businesses,such as those above, or 
when trying to track down the origins of spam mail. Of course, some people give
false information when they register domains, and some people fake return
addresses when sending out spam and so forth, so use caution when using this
information, and never harass or abuse people.

This command line version of Whois should compile and run on VMS, VAX or Alpha 
on versions 6.2 onwards. It requires that you have a TCPIP product installed 
such as Compaq TCPIP 5.1 (though it works with UCX 4.2) or Process Software's
Multinet.

To compile, if you have Compaq MMS or MadGoat MMK installed just go to the 
WHOIS directory and type MMK or MMS. If you don't have those then use the 
command file, @MAKE . For a debug version @MAKE D . You need a C compiler of 
course, such as DEC C or Compaq C.

To set up the command, @SETUP in the WHOIS directory and the symbol WHOIS will 
be set up to point to the correct location. The Alpha executable is called
WHOIS.EXE_ALPHA and the VAX one is called WHOIS.EXE .

The executables supplied are linked for VAX VMS 6.2 and Alpha VMS 7.3, so if you
get errors concerning version mismatches, just delete or rename the supplied .EXE
and .EXE_ALPHA, and relink on your system - MMK or MMS will do this for you, or
look at the MAKE.COM and LINK by hand.

To compile under Windows XP, make sure you have the VC compilation variables
set, e.g. run the batch command file
C:\"Program Files"\"Microsoft Visual Studio"\VC98\Bin\VCVARS32.BAT
then type NMAKE WHOIS.EXE. Copy the executable to your %WINDIR% then you cane 
just type WHOIS YRL.CO.UK and the lookup will be done. For convenience, the 
Intel Pentium compatible binary is included in the zip file as whois.exe_i386.
This should obviously be rename to whois.exe when it is copied to %WINDIR%.

Please report any problems to me <phil@XZYpottsoft_REMOVEXYZ.com>

Phil Ottewell 31-MAR-2002
