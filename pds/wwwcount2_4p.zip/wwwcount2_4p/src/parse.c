#include "combine.h"
#include "count.h"
#include "cdebug.h"

#ifdef SYS_WIN32
#include "configNT.h"
#elif defined( __VMS )
#include "configVMS.h"
#else
#include "config.h"
#endif

#ifdef __VMS
#define DIR_SEPARATOR "" /* Already have ] at end of _DIR macros */
#else
#define DIR_SEPARATOR "/"
#endif

/* private protos */
static void printConfigError _Declare ((int err_type));

void ParseConfig ()
{
    FILE
        *fp;

    int
        i;

    char
        buf[MaxLineLength+1];

    i=0;

    *buf='\0';

#ifdef SYS_WIN32

        /*
        ** g_sZ_vbase has a trailing \ at the end
        */
        safeStrcpy(buf,g_sZ_vbase,sizeof(buf)-1);
        safeStrcat(buf,CONFIG_DIR,sizeof(buf)-1,sizeof(buf),strlen(buf));
        safeStrcat(buf,"/",sizeof(buf)-1,sizeof(buf),strlen(buf));
        safeStrcat(buf,CONFIG_FILE,sizeof(buf)-1,sizeof(buf),strlen(buf));


#else

    safeStrcpy(buf,CONFIG_DIR,sizeof(buf)-1);
    safeStrcat(buf,DIR_SEPARATOR,sizeof(buf)-1,sizeof(buf),strlen(buf));
    safeStrcat(buf,CONFIG_FILE,sizeof(buf)-1,sizeof(buf),strlen(buf));
#endif

    fp = fopen(buf, "r");
    if (fp == (FILE *) NULL)
    {
        printConfigError(ConfigOpenFailed);
        /* we won't be here */
    }

    /*
    ** first block: automatic file creation. If the block contains 1,
    ** automatic file creation is allowed. if 0, not allowed.
    ** automatic file creation is a bad thing, but some sites may want
    ** it because they are running their server behind a firewall and
    ** they trust their users
    ** BLOCK 1
    */

    *buf='\0';
    (void) GetLine(fp, buf);
    if (strcmp(buf, "{") != 0)
    {
        (void) fclose ((FILE *) fp);
        printConfigError(NoAutofcBlock);
        /* we won't be here */
    }
    while (True)
    {
        if (!GetLine (fp, buf))
        {
            (void) fclose ((FILE *) fp);
             printConfigError(UnpexpectedEof);                       
             /* we won't be here */
        }
        if (strcmp(buf, "}") == 0)
            break;
        RemoveTrailingSp (buf);
        Gauto_file_creation=atoi(buf);
    }

    /*
    ** strict mode block
    ** BLOCK 2
    */
    *buf='\0';
    (void) GetLine(fp, buf);
    if (strcmp(buf, "{") != 0)
    {
        (void) fclose ((FILE *) fp);
        printConfigError(NoStrictBlock);
        /* we won't be here */
    }
    while (True)
    {
        if (!GetLine (fp, buf))
        {
            (void) fclose ((FILE *) fp);
             printConfigError(UnpexpectedEof);                       
            /* we won't be here */
        }
        if (strcmp(buf, "}") == 0)
            break;
        RemoveTrailingSp (buf);
        Gstrict_mode=atoi(buf);
    }

    /*
    ** rgb coloname lookup 
    ** BLOCK 3
    */
    *buf='\0';
    (void) GetLine(fp, buf);
    if (strcmp(buf, "{") != 0)
    {
        (void) fclose ((FILE *) fp);
        printConfigError(NoRgbMappingBlock);
        /* we won't be here */
    }
    while (True)
    {
        if (!GetLine (fp, buf))
        {
            (void) fclose ((FILE *) fp);
             printConfigError(UnpexpectedEof);                       
             /* we won't be here */
        }
        if (strcmp(buf, "}") == 0)
            break;
        RemoveTrailingSp (buf);
        GrgbMappingIsError=atoi(buf);
    }

    /*
    ** ignore count block
    ** BLOCK 4
    */
    *buf='\0';
    (void) GetLine (fp, buf);
    if (strcmp (buf, "{") != 0)
    {
        (void) fclose ((FILE *) fp);
        printConfigError(NoIgnoreHostsBlock);
        /* we won't be here */
    }

    while (True)
    {
        if (!GetLine (fp, buf))
        {
            (void) fclose ((FILE *) fp);
            printConfigError(UnpexpectedEof);
            /* we won't be here */
        }

        if (strcmp(buf, "}") == 0)
            break;
        RemoveTrailingSp (buf);
        /* g_ighost is initialized to NULL in main.c, it's required */
        Gsite++;
        additemToList(&g_ighost,buf);
    }

        if (Gsite > 0)
        {
            Debug2("Ignore Hosts:",0,0);
        }
        else
        {
            Debug2("Will count access from any host",0,0);
        }
        /*
        for (i=0; i < Gsite; i++)
        {
            Debug2("Site[%d] %s",i,GignoreSite[i]);
        }
        */

#ifdef ACCESS_AUTH
    (void) GetLine (fp, buf);
    if (strcmp(buf, "{") != 0)
    {
       (void) fclose ((FILE *) fp);
        printConfigError(NoRefhBlock);
        /* we won't be here */
    }
    while (True)
    {
        if (!GetLine (fp, buf))
        {
            (void) fclose ((FILE *) fp);
            printConfigError(UnpexpectedEof);
            /* we won't be here */
        }
        if (strcmp (buf, "}") == 0)
            break;
        RemoveTrailingSp (buf);
        /*
        GrefererHost[Grhost++]= mystrdup(buf);
        */

        /* g_refhost is initialized to NULL at main.c, it's essential */
        Grhost++;
        additemToList(&g_refhost,buf);

    }

        if (Grhost > 0)
        {
            Debug2("-Referer Hosts-",0,0);
        }
        else
        {
            Debug2("Grhost: %d", Grhost,0);
        }
        /*
        for (i=0; i < Grhost; i++)
        {
            Debug2("Referer[%d] %s",i,GrefererHost[i]);
        }
        */

#endif /* ACCESS_AUTH */
    (void) fclose ((FILE *) fp);
}

#ifdef TEST

void main (argc, argv)
int
    argc;
char
    **argv;
{
    ParseAuthorizationList ();
}
#endif /* TEST */


/*
 *  GetLine () - reads a line from the passed file pointer and puts the
 *               line in the passed array
 *
 *  RCS:
 *      $Revision: 2.3 $
 *      $Date: 1996/05/03 02:20:22 $
 *
 *  Security:
 *      Unclassified
 *
 *  Description:
 *      borrowed from wusage 2.3
 *
 *  Input Parameters:
 *      type    identifier  description
 *
 *      text
 *
 *  Output Parameters:
 *      type    identifier  description
 *
 *      text
 *
 *  Return Values:
 *      value   description
 *
 *  Side Effects:
 *      text
 *
 *  Limitations and Comments:
 *      text
 *
 *  Development History:
 *      who                 when        why
 *      muquit@semcor.com   05-Jun-95   first cut
 */

int GetLine (fp, string)
FILE
    *fp;
char
    *string;
{
    int
        s,
        i;

    int
        length;

    char
        *x;
    while (!feof (fp))
    {
        x = fgets (string, 80, fp);
        if (x == (char *) NULL)
            return (0);

        if (*string == '#') /* a comment */
            continue;

        if (string[(int) strlen(string)-1] == '\n')
            string[(int) strlen(string)-1] = '\0'; /* NULL terminate*/

        if (*string == '\0')
            continue;

        length = (int) strlen(string);
        s=0;

        for (i=0; i < length; i++)
        {
            if (isspace (string[i]))
                s++;
            else
                break;
        }

        if (s)
        {
            char buf[81];
            /* copying is safe here */
            (void) strcpy (buf, string+s);
            (void) strcpy(string,buf);
        }

        length = (int) strlen(string);
        for (i=(length-1); i >= 0; i--)
        {
            if (isspace(string[i]))
                string[i]='\0';
            else
                break;
        }
        return (1);
    }
    return (0);
}

/*
 *  ParseQueryString() - parses the QUERY_STRING for Count.cgi
 *
 *  RCS:
 *      $Revision: 2.3 $
 *      $Date: 1996/05/03 02:20:22 $
 *
 *  Security:
 *      Unclassified
 *
 *  Description:
 *      text
 *
 *  Input Parameters:
 *      type    identifier  description
 *
 *      char        *qs
 *      DigitInfo   *digit_info
 *      FrameInfo   *frame_info
 *
 *  Output Parameters:
 *      type    identifier  description
 *
 *      DigitInfo   *digit_info
 *      FrameInfo   *frame_info
 *
 *  Return Values:
 *      value   description
 *      0   on success
 *      1   on failure
 *
 *  Side Effects:
 *      text
 *
 *  Limitations and Comments:
 *      text
 *
 *  Development History:
 *      who                 when        why
 *      muquit@semcor.com   22-Aug-95   first cut
 */

int ParseInteger(given,sets,min,max)
char
    *given;
int
    *sets;
int
    min,
    max;
{
    if (sscanf(given, "%d", sets) == 1)
    {
        *sets = AbsoluteValue(*sets);
        if (*sets >= min && ( max == 0 || *sets <= max ))
            return(True);
    }
    return(False);
}

int ParseDigitsString(given,sets,maxlen)
char 
    *given;
char 
    *sets;
int 
    maxlen;
{
    for ( ; *given != (char) 0; given++, sets++, maxlen-- )
    {
        if (isdigit(*given) && maxlen >= 0)
            *sets = *given;
        else
            return(False);
    }
    return(True);
}

int ParseOptionString(given,sets)
char
    *given;
int
    *sets;
{
   if (mystrcasecmp(given,"counter") == 0)
   {
        *sets=SHOW_COUNTER;
        return (True);
   } 
   else if (mystrcasecmp(given,"clock") == 0)
   {
        *sets=SHOW_CLOCK;
        return (True);
   }
   else if (mystrcasecmp(given,"date") == 0)
   {
        *sets=SHOW_DATE;
        return (True);
   }
   else if (mystrcasecmp(given,"image") == 0)
   {
        *sets=SHOW_GIF_FILE;
        return (True);
   }
   else
        return (False);

return (False);
}

int ParseDateFormat(given,sets)
char
    *given;
int
    *sets;
{
    if (mystrcasecmp(given,"MMDDYY") == 0)
    {
       *sets=DATE_MMDDYY;
       return(True); 
    }
    else if (mystrcasecmp(given,"DDMMYY") == 0)
    {
       *sets=DATE_DDMMYY;
       return(True); 
    }
    else if (mystrcasecmp(given,"YYMMDD") == 0)
    {
       *sets=DATE_YYMMDD;
       return(True); 
    }
    else if (mystrcasecmp(given,"YYDDMM") == 0)
    {
       *sets=DATE_YYDDMM;
       return(True); 
    }
    else if (mystrcasecmp(given,"MMYYDD") == 0)
    {
       *sets=DATE_MMYYDD;
       return(True); 
    }
    else if (mystrcasecmp(given,"DDYYMM") == 0)
    {
       *sets=DATE_MMYYDD;
       return(True); 
    }
    else
        return (False);

return (False);
}

int ParseBool(given,sets )
char 
    *given;
int 
    *sets;
{
    if ((int)strlen(given) != 1)
        return(False);

    switch(*given)
    {
        case '1':
        case 'T':
        case 't':
        case 'Y':
        case 'y':
            *sets = True;
            break;
        case '0':
        case 'F':
        case 'f':
        case 'N':
        case 'n':
            *sets = False;
            break;
        default:
            return(False);
    }
    return(True);
}

#if __STDC__
int ParseRGB(char *given,unsigned char *set_r,unsigned char *set_g,
    unsigned char *set_b)
#else
int ParseRGB(given,set_r,set_g,set_b)
char 
    *given;
unsigned char 
    *set_r, 
    *set_g, 
    *set_b;
#endif
{
    int
        rc,
        red, 
        green, 
        blue, 
        items,
        found = False;

    FILE 
        *handle = NULL;

    char
        rgbname[MaxLineLength],
        fromfile[MaxLineLength],
        *emsg = fromfile;                   /* Reuse space! */

    rc=True;
    /*rc=sscanf(given, "%d;%d;%d",&red,&green,&blue);*/

    if ((sscanf(given, "%d;%d;%d",&red,&green,&blue) == 3) ||
        (sscanf(given,"%02x%02x%02x",&red,&green,&blue) == 3) ||
        (sscanf(given,"#%02x%02x%02x",&red,&green,&blue) == 3) ||
        (sscanf(given,"%*02x%02x%*02x%02x%*02x%02x",&red,&green,&blue) == 6)||
        (sscanf(given,"#%*02x%02x%*02x%02x%*02x%02x",&red,&green,&blue) == 6))
    {
        rc=True;
    }
    else
        rc=False;


    if (rc == False) 
    {
        handle=fopen(RGB_MAPPING_DICT, "r");
        if (handle != (FILE *) NULL)
        {
            while(fgets(fromfile, sizeof(fromfile), handle) )
            {
                /*items=sscanf(fromfile,"%d %d %d %s %*s",
                    &red,&green,&blue,rgbname);*/
                items=sscanf(fromfile,"%d %d %d %[^\n]\n",
                    &red,&green,&blue,rgbname);
                 if (items != 4)
                    continue;
                 if (mystrcasecmp(rgbname, given) == 0)
                 {
                    if ( Gdebug == True )
                       fprintf(stderr, "Found \"%d %d %d %s\" in %s\n",
                               red, green, blue, rgbname, RGB_MAPPING_DICT);
                        if (GrgbMappingIsError == 0)
                        {
                            /*
                            sprintf(emsg, "Please specify \"%d;%d;%d\" instead of \"%s\" for color.", red, green, blue, rgbname);
                            */
                            (void) sprintf(emsg,"Please specify \"%02x%02x%02x\" instead of \"%.100s\" for color.",red,green,blue,rgbname);
                            PrintHeader();
                            StringImage(emsg);
                        }
                        else
                        {
                            found=True;
                            break;
                        }
                   }
            }
            (void) fclose(handle);
            if ( found == False )
                return(False);
        }
    }

    if ( red   < 0 ) red   = 0; else if ( red   > MaxRGB ) return(False);
    if ( green < 0 ) green = 0; else if ( green > MaxRGB ) return(False);
    if ( blue  < 0 ) blue  = 0; else if ( blue  > MaxRGB ) return(False);

    *set_r = (unsigned char) red;
    *set_g = (unsigned char) green;
    *set_b = (unsigned char) blue;
    return(True);
}

int ParseSize(given,set_w,set_h )
char
    *given;
int 
    *set_w, 
    *set_h;
{
    int
        rc;

    rc=sscanf(given, "%d;%d", set_w, set_h);

    if (rc != 2)
        return(False);

    *set_w = AbsoluteValue(*set_w);
    *set_h = AbsoluteValue(*set_h);
    return(True);
}

int ParseError(keyword, value, current_rc, blurb)
char
    *keyword,
    *value;
int
    current_rc;
char
    *blurb;
{
    char 
        emsg[MaxTextLength];


    if (strlen(keyword) + strlen(blurb) + strlen(value) + 36 > sizeof(emsg))
    {
        strcpy(emsg, "A parse error occurred with excessively long strings");
    }
    else
    {
        sprintf(emsg, "Parameter \"%s=\" followed by %s value \"%s\"", 
               keyword, blurb, value);
    }

    PrintHeader();
    StringImage(emsg);
    current_rc++;
    return(current_rc);
}

int ParseQueryString(qs, digit_info, frame_info)
char
    *qs;
DigitInfo
    *digit_info;
FrameInfo
    *frame_info;
{
    char
        emsg[MaxTextLength],
        query_string[MaxTextLength];

    char
        *keyword,
        *value,
        *p;

    int
        dummy;

    int
        rc=0;


    /*
    ** assumption, initImageParams() has called
    */
    safeStrcpy(query_string,qs,sizeof(query_string)-1);
    p=query_string;

    Debug2("Parsing \"%s\"",p,0);

    while((keyword=mystrtok(p, "=")) != (char *) NULL)
    {
        p = (char *) NULL;
        value=mystrtok(p,PARAM_DELIMITERS);
        if (value == (char *) NULL)
        {
            (void) sprintf(emsg,
                "Parameter \"%.100s=\" requires a value\n", keyword);
            PrintHeader();
            StringImage(emsg);
            rc++;
            break;
        }

        Debug2("Keyword={%s}; value={%s}",keyword,value);

        /********************************************************************
        * Use of "mystrcasecmp()" is slow but fast to implement.  Will fix.
        * Error return does not occur until after entire query string is
        * parsed; this allows all errors to be shown to user in first pass.
        * Hence "rc" is incremented with each error found.
        ********************************************************************/
        if (mystrcasecmp(keyword,"ft") == 0)
        {
            if (!ParseInteger(value,&dummy,0,255))
                rc = ParseError(keyword,value,rc,
                    "badly specified frame thickness");
            else
                frame_info->width= (unsigned int) dummy;
        }
        else if (mystrcasecmp(keyword,"cache") == 0)
        {
            if (!ParseBool(value,&dummy))
                rc=ParseError(keyword,value,rc,"non-Boolean");
            else
                digit_info->cache=dummy;
        }
 
        else if (mystrcasecmp(keyword,"expires") == 0)
        {
            if (!ParseInteger(value,&dummy,0,604800))
                rc=ParseError(keyword,value,rc,
                    "bad expiration value");
            else
                digit_info->expires=dummy;
        }
        else if (mystrcasecmp(keyword,"frgb") == 0)
        {
            if ( ! ParseRGB(value,
                &(frame_info->matte_color.red),
                &(frame_info->matte_color.green),
                &(frame_info->matte_color.blue)))
                rc = ParseError(keyword,value,rc,"badly specified RGB");

        }
        else if (mystrcasecmp(keyword,"chcolor") == 0)
        {
            if (!ParseBool(value, &dummy))
                rc = ParseError(keyword,value,rc,"non-Boolean");
            else
                digit_info->replace_color=(unsigned int) dummy;
        }
        else if (mystrcasecmp(keyword,"srgb") == 0)
        {
            if (!ParseRGB(value,
                &(digit_info->opaque_red),
                &(digit_info->opaque_green),
                &(digit_info->opaque_blue)))
                rc=ParseError(keyword,value,rc,
                    "badly specified source RGB");
        }
        else if (mystrcasecmp(keyword,"prgb") == 0)
        {
            if (!ParseRGB(value,
                &(digit_info->pen_red),
                &(digit_info->pen_green),
                &(digit_info->pen_blue)))
                rc=ParseError(keyword,value,rc,
                    "badly specified pen RGB");
            else
                digit_info->replace_color=True;
        }
        else if (mystrcasecmp(keyword,"tr") == 0)
        {
            if (!ParseBool(value,&dummy))
                rc = ParseError(keyword,value,rc,"non-Boolean");
            else
                digit_info->alpha=(unsigned int) dummy;
        }
        else if (mystrcasecmp(keyword, "trgb") == 0)
        {
            if ( ! ParseRGB(value,
                &(digit_info->alpha_red),
                &(digit_info->alpha_green),
                &(digit_info->alpha_blue)))
                rc = ParseError(keyword,value,rc,"badly specified RGB");
            digit_info->alpha=True;
        }
        else if (mystrcasecmp(keyword,"md") == 0)
        {
            if (!ParseInteger(value,&(digit_info->maxdigits),5,MAX_DIGITS))
                rc = ParseError(keyword,value,rc,"bad max digits");
        }
        else if (mystrcasecmp(keyword,"pad") == 0)
        {
            if (!ParseBool(value, &dummy))
                rc = ParseError(keyword,value,rc,"non-Boolean");
            else
                digit_info->leftpad=(unsigned int) dummy;
        }
        else if (mystrcasecmp(keyword,"dd") == 0)
        {
            /* safe copy */
            safeStrcpy(digit_info->ddhead,value,
                          sizeof(digit_info->ddhead)-1);
           Debug2("sizeof(digit_info->ddhead)=%d",sizeof(digit_info->ddhead),0);
        }
        else if (mystrcasecmp(keyword,"st") == 0)
        {
            if (!ParseInteger(value, &dummy, 1,999999999))
                rc = ParseError(keyword,value,rc,"bad starting");
            else
                digit_info->st=(unsigned int) dummy;
        }
        else if (mystrcasecmp( keyword, "sh") == 0)
        {
            if (!ParseBool(value, &dummy))
                rc = ParseError(keyword,value,rc,"non-Boolean");
            else
                digit_info->show=(unsigned int) dummy;
        }
        else if (mystrcasecmp(keyword,"istrip") == 0)
        {
            if (!ParseBool(value, &dummy))
               rc = ParseError(keyword,value,rc,"non-Boolean");
            else
               digit_info->use_strip=(unsigned int) dummy;

        }
        else if (mystrcasecmp(keyword,"comma") == 0)
        {
            if (!ParseBool(value, &dummy))
               rc = ParseError(keyword,value,rc,"non-Boolean");
            else
               digit_info->comma=(unsigned int) dummy;
        }
        else if (mystrcasecmp(keyword,"nsegment") == 0)
        {
            if (!ParseInteger(value, &(digit_info->nsegment), 1,999999999))
                rc = ParseError(keyword,value,rc,"bad starting");
        }
        else if (mystrcasecmp(keyword,"df") == 0)
        {
            safeStrcpy(digit_info->datafile,value,
                           sizeof(digit_info->datafile)-1);
        }
        else if (mystrcasecmp( keyword,"incr") == 0)
        {
            if (!ParseBool(value, &dummy))
                rc = ParseError(keyword,value,rc,"non-Boolean");
            else
                digit_info->increment_counter=(unsigned int) dummy;
        }
        else if (mystrcasecmp( keyword,"negate") == 0)
        {
            if (!ParseBool(value, &dummy))
                rc = ParseError(keyword,value,rc,"non-Boolean");
            else
                digit_info->negate=(unsigned int) dummy;
        }
        else if (mystrcasecmp( keyword,"wxh") == 0)
        {
            /*
            ** do nothing, this keyword is here just for backward
            ** compatibility with Count 1.5. in the current version
            ** we determine digit dimensions automatically
            */
        }
        else if (mystrcasecmp( keyword,"rotate") == 0)
        {
            if (!ParseBool(value, &dummy))
                rc = ParseError(keyword,value,rc,"non-Boolean");
            else
                digit_info->rotate=(unsigned int) dummy;
        }
        else if (mystrcasecmp(keyword,"degrees") == 0)
        {
            if (!ParseInteger(value,&(digit_info->rotate_degrees),90,360))
                rc = ParseError(keyword,value,rc,
                    "badly specified rotation angle");
            else
                digit_info->rotate=True;
        }
        else if (mystrcasecmp(keyword,"lit") == 0)
        {
           if (!ParseLiteralString(value,digit_info->literal,100))
                rc = ParseError(keyword,value,rc,"un-supported or oversized");
        }
        else if (mystrcasecmp(keyword,"display") == 0)
        {
            if (!ParseOptionString(value,&(digit_info->display_type)))
                rc=ParseError(keyword,value,rc,"unknown");
        }
        else if (mystrcasecmp(keyword,"image") == 0)
        {
            digit_info->display_type=SHOW_GIF_FILE;
            safeStrcpy(digit_info->gif_file,value,
                    sizeof(digit_info->gif_file)-1);
        }
        else if (mystrcasecmp(keyword,"dformat") == 0)
        {
            if (!ParseDateFormat(value,&(digit_info->date_format)))
                rc=ParseError(keyword,value,rc,"invalid");
        }
        else if (mystrcasecmp(keyword,"tformat") == 0)
        {
            if (!ParseInteger(value,&(digit_info->time_format),12,24))
                rc=ParseError(keyword,value,rc,
                    "badly specified time format, (use 12 or 24)");
        }
        else if (mystrcasecmp(keyword,"script") == 0) /* for cgiwrap*/
        {
            ;
        }
        else if (mystrcasecmp(keyword,"user") == 0) /*for cgiwrap*/
        {
            ;
        }
        else if (mystrcasecmp(keyword,"timezone") == 0)
        {
            safeStrcpy(digit_info->time_z,value,
                    sizeof(digit_info->time_z)-1);
        }
        else 
        {
            sprintf(emsg, "Bad keyword \"%.100s\"", keyword);
            PrintHeader();
            StringImage(emsg);
            rc++;
        }
    }

    return(rc);
}

/*
 *  GetRemoteReferer - returns the remote referer
 *
 *  RCS:
 *      $Revision: 2.3 $
 *      $Date: 1996/05/03 02:20:22 $
 *
 *  Security:
 *      Unclassified
 *
 *  Description:
 *      text
 *
 *  Input Parameters:
 *      type    identifier  description
 *
 *      char    *host       remote referer HTML
 *
 *
 *  Output Parameters:
 *      type    identifier  description
 *
 *      char    *rem_host   retuns the host
 *
 *  Return Values:
 *      value   description
 *
 *  Side Effects:
 *      text
 *
 *  Limitations and Comments:
 *      text
 *
 *  Development History:
 *      who                 when        why
 *      muquit@semcor.com   12-Aug-95   first cut
 */

void GetRemoteReferer (host, rem_host)
char
    *host;
char
    *rem_host;
{
    register char
        *p,
        *q;

    int
        x;

    *rem_host = '\0';
    q=rem_host;

    for (p=host; *p != '\0'; p++)
    {
        if (*p == '/')
        {
            p++;
            if (*p == '/')
            {
                p++;
            }
            break;
        }
    }
    while ((*p != '/') && (*p != '\0'))
        *q++ = *p++;

    *q = '\0';

    /*
    ** randerso@bite.db.uth.tmc.edu added the following lines of code
    ** to account for port numbers at the end of a url
    */

    x=0;
    while ((x < (int) strlen(rem_host)) && (rem_host[x] != ':'))
        x++;
    rem_host[x]='\0';
}

#ifdef SYS_UNIX
void SetLock (fd)
int
    fd;
{
#ifdef HAVE_FLOCK
    (void) flock(fd,LOCK_EX);
#else
    lseek(fd,0L,0);
    (void) lockf(fd,F_LOCK,0L);
#endif
}

void UnsetLock (fd)
int
    fd;
{
#ifdef HAVE_FLOCK
    (void) flock(fd,LOCK_UN);
#else
    lseek(fd,0L,0);
    (void) lockf(fd,F_ULOCK,0L);
#endif
}
#endif  /* SYS_UNIX */

#ifndef HAVE_MKTIME
/*
 * $Author: muquit $
 * $Date: 1996/05/03 02:20:22 $
 * $Id: parse.c,v 2.3 1996/05/03 02:20:22 muquit Exp muquit $
 * $Source: /usr2/sparc/muquit/mysrc/tmp/wwwcount2.3/RCS/parse.c,v $
 *
 * Grr.. on EP/IX I have no mktime(2) routine so I've had to roll my own.
 * Original work 7-Apr-95 by Reg Quinton <reggers@julian.uwo.ca>
*/


/* this is awfully nasty, the epoch began in 1970 UTC and 1968 was
   the preceding leap year. This converts a time structure to the
   number of seconds since the leap year. But assumes I have all
   sorts of good values which might not be there and doesn't do
   any fancy work wrt. time zones (assumes date given is same
   timezone and EST/EDT offset) which obviously isn't true. */

time_t netMktime(v)
struct tm *v;
{
struct	tm	*tm;
	int	leap;
	time_t	n;

	leap= (((v)->tm_year) % 4) ? 0 : 1;

	switch ((v)->tm_mon) {
	case 0:	/* Jan */
		(v)->tm_yday=(v)->tm_mday - 1;
		break;;
	case 1: /* Feb */
		(v)->tm_yday=31 + (v)->tm_mday - 1;
		break;;
	case 2: /* Mar */
		(v)->tm_yday=59 + (v)->tm_mday - 1 + leap;
		break;;
	case 3: /* Apr */
		(v)->tm_yday=90 + (v)->tm_mday - 1 + leap;
		break;;
	case 4: /* May */
		(v)->tm_yday=120 + (v)->tm_mday - 1 + leap;
		break;;
	case 5: /* Jun */
		(v)->tm_yday=151 + (v)->tm_mday - 1 + leap;
		break;;
	case 6: /* Jul */
		(v)->tm_yday=181 + (v)->tm_mday - 1 + leap;
		break;;
	case 7: /* Aug */
		(v)->tm_yday=212 + (v)->tm_mday - 1 + leap;
		break;;
	case 8: /* Sep */
		(v)->tm_yday=243 + (v)->tm_mday - 1 + leap;
		break;;
	case 9: /* Oct */
		(v)->tm_yday=273 + (v)->tm_mday - 1 + leap;
		break;;
	case 10: /* Nov */
		(v)->tm_yday=304 + (v)->tm_mday - 1 + leap;
		break;;
	case 11: /* Dec */
		(v)->tm_yday=334 + (v)->tm_mday - 1 + leap;
		break;;
	}

	/* n is the time value GMT, I need an offset */

	n=(((((((((((v)->tm_year) - 70) * 365 + 
                          (((v)->tm_year) - 68) / 4)  + 
                           ((v)->tm_yday)) * 24 ) +
                           ((v)->tm_hour)) * 60 ) + 
                           ((v)->tm_min))  * 60 ) + 
                           ((v)->tm_sec) );

	/* find the GMT offset and take it off, this fails
	   real bad at the time the timezone changes */

	tm=localtime(&n);	return(n-tm->tm_gmtoff);
}

#endif /* !HAVE_MKTIME */

/*
 *  checkTimezone - parses the GMT+-hhmm and returns the time in seconds
 *
 *  RCS:
 *      $Revision: 2.3 $
 *      $Date: 1996/05/03 02:20:22 $
 *
 *  Security:
 *      Unclassified
 *
 *  Description:
 *      This funcions parses a string like GMT+-hhmm and returns the time
 *      in seconds.
 *
 *  Input Parameters:
 *      type    identifier  description
 *
 *      char    str[]
 *          str holds a string like GMT+-hhmm
 *
 *  Output Parameters:
 *      type    identifier  description
 *
 *      text
 *
 *  Return Values:
 *      value   description
 *      int     diff
 *          hhmm is converted to seconds before returning. the value will
 *          be positive or negative based on GMT+ or GMT-
 *
 *  Side Effects:
 *      text
 *
 *  Limitations and Comments:
 *      text
 *
 *  Development History:
 *      who                 when        why
 *      muquit@semcor.com   26-Mar-96   first cut
 */


long checkTimezone(str)
char
    str[];
{
    int
        hr,
        min;
    int
        d;
    int
        counter=0;

    char
        buf[10];

    long
        diff=0L;

    int
        i;

    *buf='\0';
    hr=0;
    min=0;
    

    if (*str != '\0')
    {
        if (strlen(str) == 8)
        {
            if ((str[3] == '-') || (str[3] == '+'))
            {
                (void) strcpy(buf,&str[4]);   
                for (i=0; i < strlen(buf); i++)
                {
                    d=buf[i];
                    if ((d >= '0') && (d <= '9'))
                    {
                        if (counter < 2)
                            hr=hr*10 +(d-'0');
                        else
                            min=min*10+(d-'0');
                        counter++;
                    }
                }
                diff=(hr*3600)+min*60;
                if (str[3] == '-')
                    diff = -(diff);
            }
        }
    }
    return (diff);
}

/*
** parse literal string
** 04/23/96
*/
int ParseLiteralString(given,sets,maxlen)
char
    *given;
char
    *sets;
int
    maxlen;
{
    for (; *given != (char) 0; given++, sets++,maxlen--)
    {
        if (((isdigit(*given) ||
             (*given == ':')  ||
             (*given == ',')  ||
             (*given == '-')  ||
             (*given == 'a')  ||
             (*given == 'A')  ||
             (*given == 'p')  ||
             (*given == 'P')) &&
            (maxlen >= 0)))
        {
            *sets=*given;
        }
        else
            return (False);
    }
    return (True);
}


/* writes the error message image and exits with 0 */
static void printConfigError(err_type)
int
    err_type;
{

    char
        tmpbuf[1024];

    switch (err_type)
    {
        case ConfigOpenFailed:
        {
            *tmpbuf='\0';
            (void) sprintf (tmpbuf,
                "Failed to open configuration file: \"%s"
                DIR_SEPARATOR "%s\"",
                    CONFIG_DIR,CONFIG_FILE);
            Warning (tmpbuf);
            PrintHeader ();
            StringImage (tmpbuf);
            exit(0);
            break;
        }

        case NoAutofcBlock:
        {
            *tmpbuf='\0';
            (void) sprintf (tmpbuf,
                "No auto file creation block in conf file: \"%s" 
                DIR_SEPARATOR "%s\"",
                    CONFIG_DIR,CONFIG_FILE);
            Warning(tmpbuf);
            PrintHeader ();
            StringImage(tmpbuf);
            exit(0);
            break;
        }

        case NoStrictBlock:
        {
            *tmpbuf='\0';
            (void) sprintf (tmpbuf,
                "No Strict mode block in conf file: \"%s"
                DIR_SEPARATOR "%s\"",
                    CONFIG_DIR,CONFIG_FILE);
            Warning(tmpbuf);
            PrintHeader ();
            StringImage(tmpbuf);
            exit(0);
            break;
        }
        case NoIgnoreHostsBlock:
        {
            *tmpbuf='\0';
            (void) sprintf (tmpbuf,
                "No IgnoreHosts Block in the configuration file: \"%s"
                DIR_SEPARATOR "%s\"",
                    CONFIG_DIR,CONFIG_FILE);

            Warning(tmpbuf);
            PrintHeader ();
            StringImage(tmpbuf);
            exit(0);
        }

        case NoRefhBlock:
        {
            *tmpbuf='\0';
            (void) sprintf(tmpbuf,"Compiled with -DACCESS_AUTH,but no such block in configuration file!");
            Warning(tmpbuf);
            PrintHeader ();
            StringImage(tmpbuf);
            exit(1);
        }

        case UnpexpectedEof:
        {
            *tmpbuf='\0';
            (void) sprintf (tmpbuf,
            "Unexpected EOF in configuration file: \"%s"
            DIR_SEPARATOR "%s\"",
                CONFIG_DIR,CONFIG_FILE);
            Warning(tmpbuf);
            PrintHeader ();
            StringImage(tmpbuf);
            exit(0);
        }

        /* 
        ** NoRgbMappingBlock was not handled, thanks to 
        ** phil@pottsoft.daemon.co.uk
        ** Nov-26-1997
        */

        case NoRgbMappingBlock:
        {
            *tmpbuf='\0';
            (void) sprintf (tmpbuf,"No RGB Mapping block in config file!");
            Warning(tmpbuf);
            PrintHeader();
            StringImage(tmpbuf);
            exit(0);
        }

        default:
        {
            Warning("unknown error code while reading config file");
            PrintHeader();
            StringImage("unknown error code while reading config file");
            exit(0);
        }
    }   /* switch */
}

/*
**  initImageParams()
**  initialized digit_info and frame_info
**
**  RCS
**      $Revision$
**      $Date$
**  Return Values:
**      none
**
**  Parameters:
**      digit_info      returns
**      frame_info      returns
**
**  Side Effects:
**      digit_info and frame_info are changed
**
**  Limitations and Comments:
**      none
**
**  Development History:
**      who                  when           why
**      ma_muquit@fccc.edu   Nov-30-1997    first cut
*/

void initImageParams(digit_info,frame_info)
DigitInfo
    *digit_info;
FrameInfo
    *frame_info;
{
    frame_info->width=(unsigned int) DEFAULT_FRAME_THICKNESS;
    frame_info->matte_color.red=(unsigned char) DEFAULT_FRAME_RED;
    frame_info->matte_color.green=(unsigned char) DEFAULT_FRAME_GREEN;
    frame_info->matte_color.blue=(unsigned char) DEFAULT_FRAME_BLUE;

    digit_info->ub=False;
    digit_info->replace_color=False;
    digit_info->cache=1;        /* cache */
    digit_info->expires=0;      /* expires right away*/
    digit_info->opaque_red=(unsigned char) DEFAULT_OPAQUE_RED;
    digit_info->opaque_green=(unsigned char) DEFAULT_OPAQUE_GREEN;
    digit_info->opaque_blue=(unsigned char) DEFAULT_OPAQUE_BLUE;

    digit_info->pen_red=(unsigned char) DEFAULT_PEN_RED;
    digit_info->pen_green=(unsigned char) DEFAULT_PEN_GREEN;
    digit_info->pen_blue=(unsigned char) DEFAULT_PEN_BLUE;

    digit_info->alpha=(unsigned int) DEFAULT_TRANSPARENCY;
    digit_info->width=(unsigned int) 15;    /* never used */
    digit_info->height=(unsigned int) 20;   /* never used */
    digit_info->maxdigits=(int) DEFAULT_MAXDIGITS;
    digit_info->leftpad=(unsigned int) DEFAULT_LEFTPAD;
    digit_info->alpha_red=(unsigned char) DEFAULT_TRANSPARENT_RED;
    digit_info->alpha_green=(unsigned char) DEFAULT_TRANSPARENT_GREEN;
    digit_info->alpha_blue=(unsigned char) DEFAULT_TRANSPARENT_BLUE;
    digit_info->st=(unsigned int) DEFAULT_STARTCOUNT;
    digit_info->show=(unsigned int) DEFAULT_SHOWCOUNT;
    digit_info->increment_counter=(unsigned int) True;
    digit_info->negate=False;
    digit_info->rotate=False;
    digit_info->rotate_degrees=270;
    safeStrcpy(digit_info->datafile,DEFAULT_DATAFILE,
            sizeof(digit_info->datafile)-1);
    Debug2("xxxxxxxxx %s",digit_info->datafile,0);
    Debug2("sizeof(digit_info->datafile)=%d",sizeof(digit_info->datafile),0);
    safeStrcpy(digit_info->ddhead,DEFAULT_DIGITS_STYLE,
            sizeof(digit_info->ddhead)-1);

    Debug2("sizeof(digit_info->ddhead)=%d",sizeof(digit_info->ddhead),0);
    *digit_info->literal = '\0';
    digit_info->display_type=SHOW_COUNTER;
    *digit_info->time_z='\0';
    digit_info->date_format=DATE_MMDDYY;
    digit_info->time_format=12;
    digit_info->use_strip=True;
    digit_info->comma=False;
    digit_info->nsegment=15;
    *digit_info->gif_file='\0';
    Debug2("xxxxxxxxx %s",digit_info->datafile,0);

}

