$!======================================================================
$! title  : purveyor_wcount_prep.com
$! author : Neil Rieck
$! created: 00.12.24
$! notes  :
$! 1. Phil Ottwell's INSTALL.COM script builds WWWCOUNT_2_4 for OpenVMS
$! systems running "OSU DECthreads HTTP Server". This script sets up a
$! fake environment for OpenVMS systems running Process Software's
$! Purveyor Encrypt Webserver so the software will run with very little
$! modification
$! 2. you should also add the "define/system" directive below to your
$! system startup file (usually sys$manager:systartup_vms.com) so the
$! program will after a reboot
$!======================================================================
$ say		:== write sys$output
$ ask		:== inquire/nopunc
$ my_web_home	:= DISK$CSMIS3:[HTTPD_PSC.HOME.] ! where my server works
$!
$ say "purveyor_wcount_prep.com"
$ say "========================"
$ say "current target: ",my_web_home
$ say ""
$ do_it = 0				! init
$ if f$logical("www_root") .eqs. "
$ then
$	do_it = 1
$ else
$	say "-w- logical 'www_root' already exists"
$	say "-w- don't answer yes if OSU DECthreads HTTP server is running here"
$	if f$mode() .nes. "BATCH"
$	then
$		ask choice "redefine logical 'www_root'? (y/N) "
$		if choice .eqs. "Y" then do_it = 1
$	else
$		do_it = 1
$	endif
$ endif
$ if do_it .eq. 1
$ then
$	say "-i- defining logical 'www_root'"
$	define/system/executive/translation=concealed www_root  'my_web_home'
$ endif
$!
$! if f$search("www_root:[000000]bin.dir") .eqs. ""
$! then
$!	say "-i- creating subdirectory 'www_root:[bin]'"
$!	cre/dir www_root:[bin]
$! else
$!	say "-w- directory 'www_root:[bin]' already exists, action skipped"
$! endif
$!
$ say "-i- done"
$ exit
