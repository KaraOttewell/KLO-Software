$!=============================================================================
$! title : purveyor_wcount_install.com
$! author: Neil Rieck <n.rieck@sympatico.ca>
$! date  : 2000-12-26
$!=============================================================================
$! INSTALL.COM - Build and Install counter with VMS DECthreads OSU Web Server
$!
$! V01-001   18-Oct-1996       Phil Ottewell <phil@pottsoft.demon.co.uk>
$!                                           <phil@yrl.co.uk>
$! V01-002   28-Jul-1997       Phil Ottewell <phil@pottsoft.demon.co.uk>
$!                             The COMBINE build explicitly uses MMK in the
$!                             DESCRIP.MMS so make MMK:=MMS if we don't have MMK
$! V01-003   30-Nov-1997       Phil Ottewell <phil@pottsoft.demon.co.uk>
$!                             GCC users should edit the MMK line to be
$!                             MMK/MACRO=(GNU_C=1)
$!
$ old_default = F$ENVIRONMENT("DEFAULT")
$ counter_path = F$ELEMENT (0, "]", F$ENVIRONMENT ("PROCEDURE")) - ".SRC.VMS" + "]"
$ counter_root = F$ELEMENT (0, "]", F$ENVIRONMENT ("PROCEDURE")) - ".SRC.VMS" + "."
$ SAY:=WRITE SYS$OUTPUT
$!
$ say "-i- building: PURVEYOR_COPY_BIN_100.C
$ cc	PURVEYOR_COPY_BIN_100
$ link	PURVEYOR_COPY_BIN_100
$ say "-i- building: PURVEYOR_COPY_BIN_101.C
$ cc	PURVEYOR_COPY_BIN_101
$ link	PURVEYOR_COPY_BIN_101
$!
$ SET DEFAULT 'counter_root'SRC]
$!
$! Have we built the count executable ?
$!IF F$SEARCH("COUNT_PROG.EXE").EQS.""
$!THEN
$   SAY "To build the COUNT_PROG.EXE program you will need MMK or MMS"
$   SAY "MMK is available from ftp.wku.edu or ftp.spc.edu ."
$   INQUIRE yeno "Would you like to build the program (NO skips to optional installation) ? [N]"
$   IF yeno
$   THEN
$!    Use MMK if it's there, else try MMS
$     IF F$TYPE(MMK).EQS.""
$     THEN
$!      If no symbol then we probably have MMS, so just define MMK to invoke MMS
$       MMK:==MMS
$     ENDIF
$!    Use MMK or MMS  - GCC  users should add /MACRO=(GNU_C=1) after MMK below
$     MMK
$   ELSE
$     GOTO install_it
$   ENDIF
$!ENDIF
$!
$install_it:
$ SAY "Would you like to copy the counter and associated directory structure"
$ INQUIRE yeno "to the target directories now ? [N]"
$ IF .NOT. yeno THEN $ GOTO exit
$! Can't install counter unless HTTP server and logicals are set up
$ IF F$TRNLNM("WWW_ROOT").EQS.""
$ THEN
$   SAY "The WWW_ROOT logical name isn't defined."
$   SAY "Please install the DECthreads OSU HTTP Server and try again"
$   GOTO exit
$ ENDIF
$! Try installing files in their correct location, assume owner is HTTP_SERVER
$ IF F$SEARCH("WWW_ROOT:[000000]WCOUNT.DIR").EQS.""
$ THEN
$!~~~	BACKUP/LOG 'counter_root'WCOUNT...]*.* WWW_ROOT:[WCOUNT...]/OWNER=HTTP_SERVER			! OSU DECthreads
$	BACKUP/LOG 'counter_root'WCOUNT...]*.* WWW_ROOT:[WCOUNT...]/OWNER=HTTPD_PSC			! my Purveyor
$ ENDIF
$!~~~	COPY/LOG 'counter_root'SRC.VMS]COUNT.COM			WWW_ROOT:[BIN]			! OSU DECthreads
$	COPY/LOG 'counter_root'SRC.VMS]PURVEYOR_COUNT.COM		WWW_ROOT:[SCRIPTS]COUNT.COM	! Purveyor
$!~~~	COPY/LOG COUNT_PROG.EXE						WWW_ROOT:[BIN]			! OSU DECthreads
$	COPY/LOG COUNT_PROG.EXE						WWW_ROOT:[SCRIPTS]		! Purveyor
$	COPY/LOG 'counter_root'SRC.VMS]PURVEYOR_WCOUNT_PREP.COM		WWW_ROOT:[000000]		! Purveyor
$ SAY " "
$ SAY "Counter installed - you will want to edit WWW_ROOT:[WCOUNT.CONF]COUNT.CFG"
$ SAY "to meet your site's requirements. For example, you need to specify which"
$ SAY "sites are allowed to use the counter in their pages.
$ SAY "See ''counter_root'DOCS] for more information on the counter."
$ SAY " "
$ SAY "Note that VMS OSU server users should use /htbin rather than /cgi-bin ."
$ SAY " "
$ SAY " e.g. <IMG SRC=""/htbin/count?dd=B"">"
$ SAY " "
$ 	cop/log  'counter_root'SRC.VMS]PURVEYOR_COPY_BIN_100.exe	WWW_ROOT:[SCRIPTS]		! ''
$ 	cop/log  'counter_root'SRC.VMS]PURVEYOR_COPY_BIN_101.exe	WWW_ROOT:[SCRIPTS]		! ''
$! IF F$SEARCH("WWW_SYSTEM:COPY_BIN.EXE").EQS.""							! DECthreads
$! THEN
$!   SAY "The counter requires the COPY_BIN program from the [.SCRIPT_CODE]"
$!   SAY "subdirectory of your HTTP_SERVER source to be present in WWW_SYSTEM: ."
$!   SAY "Set default to the HTTP [.SCRIPT_CODE] directory then:"
$!   SAY " "
$!   SAY "$ CC/PREFIX=ALL COPY_BIN"
$!   SAY "$ CC/PREFIX=ALL SCRIPTLIB"
$!   SAY "$ LINK COPY_BIN,SCRIPTLIB"
$!   SAY "$ COPY COPY_BIN.EXE WWW_SYSTEM:"
$!   SAY " "
$! ENDIF
$ SAY "That's all folks !"
$exit:
$ SET DEFAULT 'old_default'
$ EXIT
