$ on error then $ continue
$!gosub debug	! uncomment this line to debug
$ pid = f$getjpi("","pid")
$ bufio = f$getjpi("","bufio")
$ gif_file_spec = "counter_''pid'_''bufio'.gif;"
$ set prot=(S:rwed,o:rwed,g:rwed,W:rwed)/default 
$ define/user sys$output 'gif_file_spec'
$ mcr www_root:[scripts]count_prog.exe
$ mcr www_root:[scripts]purveyor_copy_bin_101.exe 'gif_file_spec' www_out: 1
$!mcr www_root:[scripts]purveyor_copy_bin_100.exe 'gif_file_spec'
$ del/nolog 'gif_file_spec'
$ del/nolog counter_*_*.gif;*/before=-0:01:00	! cleanup aborted gifs
$ exit
$!====================================================================================================
$! title  : purveyor_count.com
$! author : Neil Rieck 
$! created: 00.12.20
$! notes  :
$! 1. this script was adapted from Phil Ottewell's program called COUNT.COM
$! 2. most of Phil's features have been temporarily removed for development purposes
$! 3. to see this stuff in a browser you must activate the script from the browser's URL command line
$!    (not from within an "<IMG SRC= ... /IMG>" tag set)
$debug:
$ if f$logical("www_out") .eqs. ""
$ then
$	wwwsay := write sys$output
$ else
$	wwwsay := write www_out
$ endif
$ wwwsay := write sys$output
$ wwwsay "Content-type: text/plain"
$ wwwsay "Pragma: no-cache"
$ wwwsay "Expires: Thu, 01 Dec 1994 16:00:00 GMT"
$ wwwsay ""
$ set ver
$!==========
$ sh log/proc
$!==========
$ sh log/job
$!==========
$ sh sym/all/glo
$!==========
$ sh sym/all/loc
$!==========
$ sh dev www_in/full
$!==========
$ sh dev www_out/full
$!==========
$ return
