/*========================================================================================================================
** Title  : purveyor_bin_copy_101.c
** Author : Neil S. Rieck
** Created: 2000.12.30
** Edit   : 132 column, non-proportional font, tabs stops every 8 characters (EDIT/EDT on VT-520)
** History:
** ver who when   what
** --- --- ------ --------------------------------------------------------------------------------------------------------
** 100 NSR 001230 original program 
** 101 NSR 010101 moved the MIME header code from the associated DCL program (count.com) into this program
**     NSR 010217 send error messages stdout (rather than sterr) so we can see them in browser debug mode
**========================================================================================================================
** Purpose: I wrote this program while trying to make Phil Ottwell's VMS port of Muhammad Musquit's page counter program
** (called "wwwcount 2.4") work with Process Software Corporation's "Purveyor Encrypt WebServer" (whew! that was a mouth
** full)
**
** Phil's Ottwell's VMS port was targeted at sites using the OSU's DECthreads web server and calls an OSU executable
** called "www_system:BIN_COPY.exe" to transmit the "just generated" counter icon directly to the network connection.
** This is possible only because the source code is available for the "OSU DECthreads HTTP Server" (which means a similar
** technique could be used when adapting this counter to Compaq's VMS port of the "Apache Web Server").
**
** Since there is no source code available for "Purveyor Encrypt WebServer" (at the time this was written, Process
** Software no longer supports Purveyor but does sell it as-is and therfore has not moved the source code into the public
** domain) I needed to look for another solution.
**
** A little hacking shows that each VMS process under Purveyor has two VMS mailbox devices available called "www_out:"
** and "www_in:". I discovered that if the "www_out:" mailbox is opened in binary mode from any "C" progam, you can pass
** binary files to them. If you didn't use a "binary mode" open, the mailbox would strip off any bytes that happened to
** look like a line feed which means that you'd need to BASE-64 encode the data before sending it to the mailbox. (you'd
** also need to return a MIME header for the image which included "Content-Transfer-Encoding: BASE64")
**========================================================================================================================*/

/*------------------------------------------------------------------------------------------------------------------------
** Program Overview:
** 1. open the input file as specified by argv[1]
** 2. open the output file as specifed by argv[2]
** 3. if argv[2] won't open or is blank then send output to 'stdout' (SYS$OUTPUT on VMS)
** 4. if argv[3] = "1" then send GIF MIME from this program (more efficient) rather than DCL
** 5. note that the progam name is always argv[0]
**------------------------------------------------------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <descrip.h> 
#include <string.h> 

/*
**	VMS return codes (5-7 of each module group are not used)
**
**							++-- severity bits
**							||+- success bit	*/
#define VMS_RC_W	0	/* warning		000			*/
#define VMS_RC_S	1	/* success		001	great		*/
#define	VMS_RC_E	2	/* error		010			*/
#define VMS_RC_I	3	/* informational	011	good		*/
#define VMS_RC_F	4	/* fatal		100			*/

#define MYDEVELOP 0							/* 0=production, 1=develop */

int main ( int argc, char **argv )
{
    FILE *fp_in, *fp_out;
    extern FILE *stdout;
    char buffer[1024], one_char;					/* our 6 digit icons are around 400 bytes */
    int status, count, temp, tally;
    char *help1 = "-i-pgm help: $MCR path:program.exe arg1 arg2 arg3\n";
    char *help2 = "-i-arg help:\n 1=input fs (eg. file.dat),\n 2=output fs (eg. www_out:)\n 3=send MIME header (0=no,1=yes)\n";

    /*
    **	make sure we have 4 args (numbered 0-3)
    */
    if ( argc < 4 ){
	fprintf ( stdout,"-e-Missing argument 1\n" );
	fprintf ( stdout,help1);
	fprintf ( stdout,help2);
	exit( VMS_RC_E );						/* VMS error -e- */
    }

    /*
    **	open the input fs (use command line argument #1)
    */
    fp_in = fopen ( argv[1], "rb" );					/* open file from command line param #1 */    
    if ( !fp_in ) {
	fprintf ( stdout,"-e-Can't open input file\n" );
	exit( VMS_RC_E );						/* VMS error -e- */
    }

    /*
    **	optionaly, send the MIME header (note: probably not be allowed in BINARY mode)
    */
    if (strcmp(argv[3],"1")==0){					/* if MIME Header was desired */
	/*
	**	open the output fs (non-binary mode)
	*/
	fp_out= fopen ( argv[2], "w" );					/* usually 'www_out:' for Purveyor */
	if ( !fp_out ) {
		fprintf ( stdout,"-e-Can't open '%s'\n", argv[2]);
		fprintf ( stdout,"-i-Assuming non-web debug (redirecting output to 'stdout')\n");
		fp_out= stdout;
	}
	fprintf( fp_out, "Content-type: image/gif\r\n");
	fprintf( fp_out, "Pragma: no-cache\r\n");
	fprintf( fp_out, "Expires: Thu, 01 Dec 1994 16:00:00 GMT\r\n");
	fprintf( fp_out, "\r\n");					/* MIME requires a trailing blank line */
	fclose( fp_out );
    }

    /*
    **	open the output fs (binary mode)
    */
    fp_out= fopen ( argv[2], "wb" );					/* usually www_out: for purveyor */
    if ( !fp_out ) {
	fprintf ( stdout,"-e-Can't open '%s'\n", argv[2]);
	fprintf ( stdout,"-i-Assuming non-web debug (redirecting output to 'stdout')\n");
	fp_out= stdout;							/* non-binary is better for debugging */
    }
    /*
    **	now read the file and send it to purveyor
    */
    tally = 0;
    while (!feof(fp_in) ) {
	count = fread ( buffer, sizeof(char), sizeof(buffer), fp_in );	/* read as much as possible */
#if MYDEVELOP==0
	if (count>0)
		fwrite(buffer, 1, count, fp_out);
	else
		break;							/* exit while loop */
#else
	tally = tally + count;
	for (temp=0; temp<count; temp++)
	{
		one_char = buffer[temp];
		if ((one_char <' ') || (one_char>'z')) one_char = ' ';
		fprintf(fp_out, "%4d = %4d %c\r\n", temp, buffer[temp], one_char);
	}
	printf("tally=%d count=%d\r\n",tally,count);
#endif
    }
    fclose( fp_in );
    if (fp_out != stdout)
	fclose( fp_out );
    exit( VMS_RC_S );							/* VMS success -S- */
}
