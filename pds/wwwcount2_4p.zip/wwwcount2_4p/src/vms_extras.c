#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <descrip.h> 
#include <starlet.h>								/* VMS system calls */
#include <lib$routines>								/* VMS run-time library calls */
#include <lbrdef.h>								/* VMS run-time library definitions */
#include <ssdef.h>								/* system services constants */
#include <lckdef.h> 

	/*
	**	The first call to lib$get_ef always yields 63 while the second call always yields 62.
	**	We'll save some CPU resources now by hardcoding values 63 + 62 rather than calling lib$getef 
	*/
	long vms_timer_ef	= 63;						/* timer event flag */
	long vms_dlm_ef		= 62;						/* distributed lock manager event flag */
	long vms_timer_bm, vms_dlm_bm;						/* event flag bit maps */
	long timer_ident, vms_flags;
	unsigned short	vms_rc;							/* return code (from vms system calls) */

	struct lock_status_block_struct{					/* define a new data structure */
		unsigned short	lock_condition,
				reserved;
		unsigned long	lock_ident;					/* lock id */
		char		lock_value[16];					/* only required with flag: LCK$M_VALBLK */
	} lock_status_block;

	/*
	** 	call the distributed lock manager to request a "protected write lock" on the "named resource"
	**	wait here until we've been granted the lock (first-come, first-served) or we time out
	*/
	int vms_request_lock(char *passed_res_nam)
	{	long passed_length, overshoot;
		/*--------------------------------------------------------------------------------
		**	arm a system timer to expire 20 seconds from now
		*/
		struct quad_struct{						/* 64 bit structure for VMS time */
			unsigned long	long0,
					long1;
		} quad_time;

		$DESCRIPTOR(delay_string,"0 ::20");				/* we will wait no longer than 20 seconds */
		struct dsc$descriptor_s resource_name;

		vms_rc = sys$bintim(	&delay_string,				/* convert text to quad time */
					&quad_time);
        	if ((vms_rc&1)!=1){
        	        printf("-e-sys$bintim rc: %d\n",vms_rc);
        	        return(2);
        	}

		/*
		**	SYS$SETIMR [efn] ,daytim ,[astadr] ,[reqidt] ,[flags] 
		*/
		vms_rc = sys$setimr( vms_timer_ef, &quad_time, 0, &timer_ident, 0);	/* arm the timer */
		if ((vms_rc&1)!=1){
			printf("-e-sys$settimr rc: %d\n",vms_rc);
			return(2);
		}

		/*--------------------------------------------------------------------------------
		**	now request an exclusive lock on the named resource
		**
		**	notes:
		**	1. set up a 'VMS Style' string descriptor for the $enq system call
		**	2. the Distributed Lock Manager may only accept a maximum string size of 31.
		**	   If we're passed a string greater than 31 characters then we'll chop it down.
		**		eg.	before:	"www_root:[wcount.dat]zzz_my_datafile_19991231.dat"
		**			after:	"at]zzz_my_datafile_19991231.dat"
		**	3. this method won't protect the datafile from locks set by VMS apps 
		*/
		passed_length = strlen( passed_res_nam );
		if (passed_length>31)
			overshoot = passed_length - 31;
		else
			overshoot = 0;

		resource_name.dsc$w_length	= strlen( passed_res_nam ) - overshoot;
		resource_name.dsc$a_pointer	= passed_res_nam + overshoot;
		resource_name.dsc$b_class	= DSC$K_CLASS_S; 
		resource_name.dsc$b_dtype	= DSC$K_DTYPE_T;

		/* 
		** SYS$ENQ [efn] ,lkmode ,lksb ,[flags] ,[resnam] ,[parid] ,[astadr] ,[astprm] ,[blkast] ,[acmode] ,[rsdm_id]
		**	Note: sys$enq is asychronous while sys$enqw is asychronous (could wait forever)
		*/
		vms_rc = sys$enq(	vms_dlm_ef		,/* efn:						*/
					LCK$K_EXMODE		,/* lkmode: exclusive access				*/
					&lock_status_block	,/* lksb:						*/
					0	 		,/* flags:						*/
					&resource_name		,/* resname: name of the protected resource 		*/
					0,0,0,0,0,0,0,0 );
		if ((vms_rc & 1)!=1)
		{	printf("-e-enq, could not request a lock rc:%d\n",vms_rc);
			return (vms_rc & 1);
		}

		/*--------------------------------------------------------------------------------
		**	prepare to wait until either the call to the timer or enq raises their respective event flags
		*/
		vms_timer_bm	= 1 << (vms_timer_ef	& 31);			/* use timer event flag to form a bit mask */
		vms_dlm_bm	= 1 << (vms_dlm_ef	& 31);			/* use DLM event flag to form a bit mask */

		vms_rc= sys$wflor( vms_timer_ef, vms_timer_bm | vms_dlm_bm );	/* wait for either one of the event flags */
		if ((vms_rc&1)!=1){
			printf("-e-sys$wflor rc: %d\n",vms_rc);
			return(2);
		}

		/*--------------------------------------------------------------------------------
		**	at this point either the "timer" or "lock manager" event flags will be set
		** 	1. if the timer event flag is clear, then we aquired the lock so cancel the timer and continue
		** 	2. if the timer event flag is set, then we didn't get the lock so deque the request and abort
		*/
		vms_rc= sys$readef( vms_timer_ef, &vms_flags);			/* test the timer event flag */
		if ((vms_rc&1)!=1){
			printf("-e-sys$readef rc: %d\n",vms_rc);
			return(2);
		}else{
			switch (vms_rc)
			{	case SS$_WASSET:				/* bad (we've timed out) */
					vms_rc = sys$deq( lock_status_block.lock_ident, 0, 0, LCK$M_DEQALL );
					if ((vms_rc&1)!=1){
						printf("-e-sys$deq rc: %d\n",vms_rc);
						return(2);
					}
					return(2);
				case SS$_WASCLR:				/* good */
					vms_rc= sys$cantim(&timer_ident, 0);
					if ((vms_rc&1)!=1){
						printf("-e-sys$cantim rc: %d\n",vms_rc);
						return(2);
					}
			}
		}
		return(1);							/* signal that we've got the lock */
	}

	/*
	**	remove "our intrest" in this resource
	**
	**	SYS$DEQ [lkid] ,[valblk] ,[acmode] ,[flags] 
	*/
	int vms_release_lock()
	{	vms_rc = sys$deq(	lock_status_block.lock_ident	,/* lkid:	*/
					0				,/* valblk:	*/
					0				,/* acmode:	*/
					LCK$M_DEQALL			 /* flags:	*/
					);
		if ((vms_rc & 1)!=1)
		{	printf("-e-deq, could not dequeue lock rc:%d\n",vms_rc);
		}
		return (vms_rc & 1);
	}
