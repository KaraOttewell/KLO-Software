 int vms_request_lock(char*);
 int vms_release_lock();
