Mon Dec  1 01:09:32 EST 1997
OSF1 chaos V3.0 347 alpha
