Mon Dec  1 00:50:22 EST 1997
gzip 1.2.4 (18 Aug 93)
Compilation options:
DIRENT UTIME STDC_HEADERS HAVE_UNISTD_H ASMV 
Linux madina 2.0.27 #1 Sat Dec 21 23:44:11 EST 1996 i686
