$ macro/nodebug mbox
$ SET COMMAND /OBJECT=MBOX_CLD.OBJ  MBOX_CLD.CLD
$ MESSAGE /NOLIST/OBJECT=MBOX_MSG.OBJ MBOX_MSG.MSG
$ q = ""
$ if f$getsyi ("ARCH_TYPE") .eq. 2 then q := "/sysexe"
$ link/notrace/nodebug'q' mbox.obj, mbox_cld.obj, mbox_msg.obj
$ runoff mbox_help.rno/out=mbox_help.hlp
$ !
