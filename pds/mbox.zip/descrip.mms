objects = mbox.obj, mbox_cld.obj, mbox_msg.obj

all : mbox.exe, mbox_help.hlp
   !

mbox.exe : $(objects)
   q = ""
   if f$getsyi ("ARCH_TYPE") .eq. 2 then q := "/sysexe"
   link/notrace/nodebug'q' $(objects)

mbox.obj : mbox.mar
   macro/nodebug mbox

mbox_help.hlp : mbox_help.rno
   runoff mbox_help.rno/out=mbox_help.hlp
