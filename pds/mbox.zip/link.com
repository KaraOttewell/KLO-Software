$ sv = 'f$verify(0)'
$ say := write sys$output
$ axp = f$getsyi("HW_MODEL").ge.1024
$ if axp
$ then	obj = "ALPHA_OBJ"
$	sysexe = "/SYSEXE"
$ else	obj = "OBJ"
$	sysexe = ""
$ endif
$ say "Linking MBOX...."
$ link/notrace mbox.'obj',mbox_cld.'obj',mbox_msg.'obj''sysexe'
$ exit 1.or.f$verify(sv)
